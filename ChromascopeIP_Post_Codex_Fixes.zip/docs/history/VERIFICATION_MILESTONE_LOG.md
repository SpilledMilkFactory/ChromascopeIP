# M0.3 Red/Orange Classification — Verification Record

**Date:** 2026-11-09 (America/New_York)

**Current source version:** 1.0.0 (M12.1 release-candidate freeze; no public release authorization).
**Historical source version:** 0.1.3 (M0.3 accepted; M1.1 was documentation-only).

**Target:** Ubuntu 26.04, OpenCV **5.1.0**, Dear ImGui **1.93.0**, CMake + Ninja.

## Context and observed defect

I previously corrected the HSV 179/0 hue-wrap median and verified by inspecting the M0.1 GUI output that every candy circle in the four original photographs is found. However, the leftmost red-labeled candy near `(285,581)` on s1 and the lower red-labeled candy near `(734,508)` on s3 are actually **orange**. Coordinates below use a 1200-pixel-wide analysis image, not original-photo pixels.

The old classifier considered hue 0–7 red and hue 8–19 orange. The affected orange surfaces have median HSV approximations of `(5,187,209)` and `(7,207,219)`. The genuine red candies in these images have median hue near 0 or 179 and considerably lower median value. This is **a classification error, not a missing Hough circle**; detection settings do not need to change.

## M0.3 corrective implementation

I now check a **bright, saturated orange band first**: hue 4–19, saturation at least 125, value at least 140. Only then do I evaluate the original red band (hue 0–7 or 162–179, saturation at least 115, value at least 62). The red rule still applies to lower-value pixels in the hue overlap. The cyclic hue median introduced in M0.1 remains untouched.

This is a **legacy-photograph-calibrated HSV heuristic**, not a claim that color names universally correspond to fixed HSV boundaries: under different illumination, camera white balance, or materials, bright reds and dark oranges may overlap. The larger image-processing project will need flexible, calibrated or learned processing profiles.

I added direct classification checks at warm hues 3, 4, 5, 7, 8 and at the HSV 179 seam, including a low-value red guard. I also added **position-based orange regression tests** on s1 and s3 so that unrelated detections cannot disguise a color swap. The existing red spatial tests in s1/s2 remain, and the s1/s3 minimum red counts have been adjusted from the M0.1 overcounts of 3 to their actual count of 2. Hough defaults, GUI controls, and CLI arguments are unchanged.

## OpenCV 4.13 exploratory reference — not native sign-off

I reproduced the updated C++ rules with the available OpenCV **4.13** Python bindings, using the four archived JPEGs, the default 1200-pixel analysis size and Hough parameters (`HOUGH_GRADIENT`, `dp=1.2`, `minDist=36`, `param1=95`, `param2=31`, `minRadius=18`, `maxRadius=54`), the same circular-hue median, and the same per-pixel confidence test. The expected results are:

| Photo | Total | Red | Orange | Yellow | Lime | Purple |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| s1.jpg | 19 | 2 | 2 | 6 | 3 | 6 |
| s2.jpg | 8 | 2 | 0 | 1 | 3 | 2 |
| s3.jpg | 19 | 2 | 2 | 6 | 3 | 6 |
| s4.jpg | 16 | 2 | 1 | 5 | 3 | 5 |

The previously incorrect orange locations were both classified as **orange** in the reference implementation. Both s1/s2 red regression locations remained **red**. All four original input JPEGs are preserved byte-for-byte.

**The OpenCV 4.13 reference above was exploratory rather than native evidence.** The subsequent Ubuntu 26.04 OpenCV 5.1.0 native build and CTest pass are recorded in the acceptance update below. That later result does not retroactively make the exploratory reference a native test.

## Native Ubuntu 26.04 acceptance procedure

From my ChromascopeIP source checkout, after applying the M0.3 patch:

```bash
cmake -S . -B build -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_PREFIX_PATH="$HOME/.local/opt/opencv-5.1.0" \
  -DCHROMASCOPE_BUILD_GUI=ON \
  -DCHROMASCOPE_BUILD_TESTS=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
ctest --test-dir build -V
./build/chromascope-cli --version
./build/chromascope-cli --input samples/skittles/s1.jpg --json s1-m03.json --output s1-m03.jpg
./build/chromascope-cli --input samples/skittles/s3.jpg --json s3-m03.json --output s3-m03.jpg
./build/chromascope-gui
```

- [ ] CMake confirms OpenCV 5.1.0 and Dear ImGui 1.93.0; the C++ build is warning-free.
- [ ] All four existing CTest entries pass, including the strengthened `chromascope_core` test.
- [ ] At default settings, s1 reports 19 candidates: **2 red and 2 orange**, with the orange near `(285,581)`.
- [ ] At default settings, s3 reports 19 candidates: **2 red and 2 orange**, with the orange near `(734,508)`.
- [ ] At default settings, s2 reports 8 candidates, including both red objects; s4 reports approximately 16 candidates without obvious color regressions.
- [ ] Original central red locations near `(655,483)` on s1 and `(566,565)` on s2 remain detected and classified red.
- [ ] CLI JSON counts and annotated exports agree with the GUI; unrelated still-image loading/export remains functional.
- [ ] The original sample photographs are unchanged.

The original checklist above records the requested M0.3 acceptance procedure; the subsequently reported results are documented below, without claiming that every optional CLI/export check was performed.

## Milestone history

- **M0 (0.1.0):** I introduced the C++ core, CLI, Dear ImGui GUI, and original photo regression suite. Initial Ubuntu CTest reported 3/4 pass due to an overly strict category assertion.
- **M0.1 (0.1.1):** I corrected the red hue-wrap median, the inaccurate sample-3 color assertion, and compiler narrowing warnings; the red objects missing from s1/s2 were subsequently visible in the GUI. The initial s1/s3 orange classification was still imperfect.
- **M0.3 (0.1.3):** I refined the bright orange / red overlap and added orange spatial regressions. There is no separate M0.2 delivery in this history; the milestone number follows my requested naming.

## M0.3 native acceptance update (reported November 9, 2026)

I confirmed that the M0.3 GUI now draws and correctly classifies every Skittles circle in the four reference photographs, including the two orange/red corrections in s1 and s3. I configured and built the project on Ubuntu 26.04 (GCC 15.2.0, Release, OpenCV 5.1.0) with the GUI and tests enabled and recorded **4/4 passing CTests**, zero failed. The build log shared for this acceptance did not show C++ warnings. This is the accepted baseline for M1.

I did **not** receive additional CLI JSON/export logs, a Windows build report, or cross-distribution results with this acceptance. I do not claim them here.

## M1.1 repository-governance checks

I added repository issue forms, a PR template, contribution guidance, and a security policy. These changes do not alter executable sources, CMake configuration, dependency pins, test behavior, or the version number. Configuration syntax and patch integrity are verified separately during package preparation; I will confirm the rendered issue chooser and pull request template after this change is merged into the default branch. I will also explicitly enable GitHub private vulnerability reporting in repository settings, since a SECURITY.md file alone cannot enable it.

## M1.2 build presets and repository hygiene — preparation

I introduced tracked CMake configure/build/test presets with separate `build/presets/<preset>/` outputs for Linux Release, Debug, and CLI-only development, plus Windows CLI-only definitions for future verification. I added a Git-ignored `CMakeUserPresets.json` example to keep per-machine OpenCV prefixes out of the repository. I also tightened root ignore rules, text/binary attributes, and out-of-source CMake configuration checks. No source algorithms, test expectations, dependency versions, or sample images were changed.

In the prepared source package I check the `cmake --list-presets`, `cmake --build --list-presets`, and `ctest --list-presets` commands, the Git patch integrity, and the ZIP contents. These checks verify preset *syntax and structure*; they do not substitute for a native OpenCV 5.1.0 compilation or CTest run. Ubuntu acceptance results should be added after executing the commands below locally:

```bash
cmake --preset linux-release
cmake --build --preset linux-release --parallel
ctest --preset linux-release
./build/presets/linux-release/chromascope-gui

cmake --preset linux-cli-debug
cmake --build --preset linux-cli-debug --parallel
ctest --preset linux-cli-debug
./build/presets/linux-cli-debug/chromascope-cli --version
```

### M1.2 preparation checks performed (November 9, 2026)

I validated the prepared source package with **CMake 3.31.6** and **Ninja 1.12.1**, not the native Ubuntu 26.04 OpenCV installation. The following results are established:

- **PASS:** All Linux configure presets appear in `cmake --list-presets` and their matching build/test presets appear in the corresponding CMake/CTest listings.
- **PASS:** A copied `CMakeUserPresets.json` example exposes its custom configure/build/test preset; the local file is Git-ignored.
- **PASS:** Linux CLI Release/Debug configurations generate separate build trees, set the expected build type, disable the GUI, and register four existing CTests. This configuration-only check used a **temporary test-only CMake OpenCV package stub** and **did not compile or run OpenCV**.
- **PASS:** The existing explicit out-of-source CMake command still configures in the same test-only environment, while an in-source configure is rejected by the new guard.
- **PASS:** `git diff --check` (for the staged patch), `git apply --check`, patch replay, ZIP integrity, byte-for-byte patched-source/ZIP comparison, executable permission on the OpenCV bootstrap script, and preservation of all four sample JPEGs and runtime C++ sources/tests.

**Not verified here:** Any C++ compilation against real OpenCV 5.1.0, CTest execution, launching the GUI, or native Windows builds. The last actual Ubuntu CTest result remains the **4/4 passing M0.3 acceptance report** supplied before this patch.

I will not mark M1.2 accepted until the Release and Debug presets, both baseline GUI/CLI behaviors, and the original four CTests are verified on Ubuntu 26.04. Windows CLI presets remain unverified pending Windows CI work in M1.6.


## M1.3 independent CTest suites — source preparation (November 9, 2026)

I separated the existing mixed `chromascope_core` test into dedicated color and validation unit tests, an OpenCV synthetic integration test, and an original-photograph regression test. I added byte-integrity verification of the four JPEGs and a real-CLI PNG/JSON export contract test. The three existing CLI help/sample/bad-input checks remain registered. CTest labels now identify suite layers for local runs and future Actions jobs; the expected suite contains **nine tests**. The historical red/orange regression coordinates and default detector settings remain unchanged.

I use [`TESTING.md`](../TESTING.md) as the authoritative test map. For acceptance on Ubuntu 26.04, I will record the full output of:

```bash
cmake --preset linux-release
cmake --build --preset linux-release --parallel
ctest --preset linux-release
ctest --test-dir build/presets/linux-release -N
ctest --test-dir build/presets/linux-release --output-on-failure -L unit
ctest --test-dir build/presets/linux-release --output-on-failure -L regression
ctest --test-dir build/presets/linux-release --output-on-failure -L cli
```

**Acceptance pending:** Native compilation of the split C++ tests and full 9/9 CTest execution against OpenCV 5.1.0, followed by any relevant manual GUI smoke check. Source-structure, CMake-configure, SHA-256, and patch checks performed outside the Ubuntu machine must be reported separately, without implying that they establish a native passing test run.

## M1.3 native acceptance (reported November 9, 2026)

I accepted the M1.3 testing reorganization after running all **9/9 CTests** successfully under the `linux-release`, `linux-debug`, and `linux-cli-release` presets on Ubuntu 26.04 with OpenCV 5.1.0. I also ran CTest label filters for `unit` (2/2), `regression` (2/2), and `cli` (4/4). The GUI continued to behave correctly during my manual review. These are reported native results, not checks independently run inside the packaging environment.

## M1.4 Ubuntu GitHub Actions — implementation and pending acceptance

I introduced `.github/workflows/ci-ubuntu.yml` with explicit `ubuntu-24.04` and `ubuntu-26.04` matrix jobs. Each job installs build prerequisites, uses isolated OpenCV 5.1.0 from a verified revision (building it on cache miss), builds the GUI and CLI with the Release preset, and runs all nine CTests. The job then independently configures/builds the CLI-only preset and reruns all nine CTests.

During artifact preparation I verified the workflow YAML structure, bash script syntax, OpenCV source-revision assertion behavior, CMake preset names, patch application, original JPEG integrity, and source ZIP equivalence. These are **static/packaging validations only**; I have not run the new workflow on GitHub or compiled against OpenCV 5.1.0 on both hosted runners.

**Acceptance pending:** I will merge M1.4 only after the real GitHub Actions matrix reports success for both Ubuntu versions, checks compile the GUI and CLI, and 9/9 native CTests pass per configured build. GUI interaction and webcam hardware are excluded from the hosted CI claim. I will preserve run links and failures if the first run identifies a portability problem.

## M1.4 Ubuntu CI acceptance (reported November 9, 2026)

I confirmed that the pull request showed **two successful GitHub Actions checks**: `Ubuntu CI / ubuntu-24.04 / Release / CTest` and `Ubuntu CI / ubuntu-26.04 / Release / CTest`. The screenshot showed both green, and I merged the pull request afterward. I also ran Release and CLI-only Release locally on Ubuntu 26.04; **9/9 CTests passed** in each configuration and I verified the GUI behavior manually. The provided records do not include a hosted Actions run URL, commit SHA, or per-step logs; I do not fabricate those identifiers. These subsequent results supersede the older M1.4 *pending acceptance* preparation notes above.

## M1.5 Debian 12/13 container CI — prepared, not hosted-verified

I added `.github/workflows/ci-debian.yml`, which provisions independent AMD64 Debian 12 (Bookworm) and Debian 13 (Trixie) containers. Each validates its `/etc/os-release` major version, installs C++20 build dependencies and GitHub Actions support tools inside the container, restores or builds isolated OpenCV 5.1.0 with the expected commit marker, compiles the GUI/CLI Release configuration, runs all nine CTests, then separately configures the CLI-only Release build and reruns the same nine CTests.

I pinned the official Debian AMD64 OCI image digests and Actions revisions, limited token permissions, isolated OpenCV caches by distribution and base-image revision, and retained the accepted Ubuntu workflow unchanged. I documented the dependency and headless-GUI qualification boundaries in [CI_DEBIAN.md](../CI_DEBIAN.md). No C++ production code, CMake configuration, tests, original JPEGs, or dependency versions were changed in M1.5.

### M1.5 acceptance checklist

- [ ] `Debian CI / debian-12 / Release / CTest` completes successfully on a hosted Actions run.
- [ ] `Debian CI / debian-13 / Release / CTest` completes successfully on a hosted Actions run.
- [ ] Both jobs report the expected Debian major version, AMD64 architecture, and verified OpenCV 5.1.0 source revision.
- [ ] Both jobs compile the core, CLI, and GUI in Release mode and pass **9/9 CTests**.
- [ ] Both CLI-only configurations build and independently pass **9/9 CTests**.
- [ ] Neither job relies on the Ubuntu host's OpenCV, compiler, headers, or GUI libraries for its application build.
- [ ] Any CI-only portability problems are resolved and rerun; the accepted Ubuntu CI stays green.
- [ ] The GitHub PR is reviewed and merged and issue #7 is closed / moved to Done.

**Not yet verified:** Debian 12 and 13 hosted compilation/CTest execution, native Debian GUI launch, webcam hardware, `.deb` installation, and distribution-runtime compatibility. Local workflow syntax and patch-integrity validation is not a substitute for either hosted CI check.

### M1.5 local preparation checks (November 9, 2026)

I completed the following non-hosted checks while preparing this patch:

- **PASS:** Parsed the new workflow YAML and confirmed the `pull_request`, `push` to `main`, and `workflow_dispatch` triggers, read-only permissions, two distinct Debian matrix entries, and full-SHA action pins.
- **PASS:** Validated both immutable Debian image-digest formats, matrix version identifiers, independent OpenCV cache keys, and complete `linux-release` / `linux-cli-release` configure/build/CTest commands.
- **PASS:** Parsed every new inline `run` script with `bash -n`.
- **PASS:** Configured the unchanged CLI-only CMake project and listed **nine registered CTests** using a temporary OpenCV package stub. This did **not** compile C++ or execute those tests.
- **PASS:** `git diff --cached --check`, clean Git patch application against the uploaded M1.4 source snapshot, and byte-for-byte equivalence between the patched source tree and the ZIP, including executable permissions.
- **PASS:** SHA-256 hashes of the four original Skittles photographs matched the uploaded M1.4 baseline. The accepted Ubuntu workflow, production code, CMake files, and native test files were unchanged.

I have **not** run native Debian 12/13 builds or CTests here. The first successful hosted GitHub Actions runs remain the required M1.5 acceptance evidence.


## M1.5 Debian CI acceptance (reported November 9, 2026)

I confirmed that the Debian 12 Bookworm and Debian 13 Trixie GitHub Actions jobs completed successfully, alongside the existing Ubuntu 24.04 and 26.04 jobs. The M1.5 pull request was subsequently merged. My local Ubuntu 26.04 Release and CLI-only Release suites each passed **9/9 CTests**, and I manually confirmed the GUI remained functional. This is the accepted baseline for M1.6.

## M1.6 Windows x64 core/CLI CI preparation — issue #8

I added `.github/workflows/ci-windows.yml` targeting **Windows Server 2022 x64** with the Visual Studio 2022 toolchain. The core, CLI, and all nine CTests are built in Release mode against statically compiled OpenCV 5.1.0; the GUI is explicitly disabled. The source bootstrap checks commit `e4f78fbcf1a773fbed69e14500e8b734963eb585` and configures OpenCV's static libraries with the dynamic MSVC runtime (`BUILD_WITH_STATIC_CRT=OFF`). The workflow checks the build metadata and locates `OpenCVConfig.cmake` before configuring ChromascopeIP.

I updated the Windows CMake presets to use the **Visual Studio 17 2022 x64** generator with explicit Release/Debug build and test configurations. The Debug preset is preparatory only; only Release is in the M1.6 gate. Linux and Debian workflows and the application algorithms are unchanged.

**Prepared-source checks (not hosted Windows results):** I check JSON and YAML parsing, CMake preset registration, workflow permissions and runner selection, the presence of all nine CTest definitions, PowerShell bootstrap and pipeline contracts, Git patch replay and package equivalence, and SHA-256 integrity of the original JPEG samples. This container does not provide a Windows/MSVC host, so I do not claim a Windows build or CTest result in the prepared artifact.

**Required hosted acceptance:**

- [ ] Windows Actions check starts on `windows-2022`, x64 with MSVC 2022.
- [ ] OpenCV source revision and static `/MD` build configuration are verified.
- [ ] ChromascopeIP Release core and CLI compile without new blocking warnings or errors.
- [ ] All nine native Windows CTests pass (including JPEG/PNG and JSON export).
- [ ] `chromascope-cli.exe --version` works; no GUI build is claimed.
- [ ] Ubuntu 24.04/26.04 and Debian 12/13 checks remain successful.
- [ ] The linked PR is merged and issue #8 is accepted.

A green `windows-2022` server job does not qualify the Windows 10/11 user-facing release packages, GUI, or camera support. Those require separate platform acceptance later in the roadmap.


## M1.6 Windows static OpenCV exported-target correction (hosted verification pending)

I inspected the second failed Windows Server 2022 Actions log (`logs_115735776772.zip`). The pinned OpenCV 5.1.0 build and install completed, and the corrected `x64/vc17/staticlib` configuration was selected. During ChromascopeIP CMake configuration, however, OpenCV's `OpenCVModules.cmake` failed while importing target `libprotobuf`, which referenced a missing `liblibprotobuf.a` in the installed static package. The OpenCV configure log showed that bundled Protobuf 3.19.1 had been enabled even though the M1.6 target only needs `core`, `imgproc`, and `imgcodecs`.

I corrected the Windows OpenCV bootstrap to pass `WITH_PROTOBUF=OFF`. The bootstrap now uses a standalone MSVC Release consumer to configure, compile, link, and run a PNG encode/decode check against the **installed** static OpenCV package before writing its provenance marker. The Windows Actions workflow runs the same consumer check on cache hits and fresh installs, verifies `protobuf=OFF` metadata, and changes the cache key so an old missing-Protobuf installation is not reused. Linux workflows, C++ algorithms, CMake presets, original photographs, and the nine CTests remain unchanged.

**Static/package checks performed here:** YAML and PowerShell source contracts, bootstrap/consumer configuration assertions, Git patch replay, ZIP equivalence and unchanged sample hashes. I have not executed Visual Studio/MSVC or run the hosted Windows workflow in this environment. M1.6 can only be accepted after the full Windows CI job, including the consumer smoke and 9/9 CTests, succeeds; the four previously accepted Linux jobs must remain green.


## M1.6 Windows third hosted failure: MSVC pthread link dependency (November 9, 2026)

I inspected Windows Actions run `115741380966`. The previous OpenCV Protobuf
correction allowed a complete source build and an installed-package consumer
CMake configuration; the MSVC consumer then failed at link time:
`LNK1181: cannot open input file 'pthread.lib'`. The dependency summary listed
`Extra dependencies: pthread` with Windows `Concurrency` as the parallel framework.

I added a Windows/MSVC-only OpenCV `POST_DETECT_DEPENDENCIES.cmake` hook to remove
the inappropriate POSIX pthread entry before the exported targets are created.
The pinned upstream OpenCV source and the Windows native concurrency backend
remain unchanged. The bootstrap passes the hook directory, the cache key includes
the hook hash, and the expected provenance marker includes
`windows_pthread_hook=ON`. The independent C++ PNG consumer remains required on
both fresh builds and cache hits; all nine ChromascopeIP CTests remain required.

**Local validation performed:** Hook parsing and list-removal behavior using
synthetic CMake script inputs; Git patch syntax and replay against the uploaded
source baseline; workflow YAML structure; full-source ZIP equivalence; and
unchanged Linux workflows / C++ code / original test fixtures.

**Native Windows build + all nine Windows CTests:** PENDING the next GitHub
Actions run. The previous failed run does not constitute M1.6 acceptance.

## M1.6 acceptance — November 9, 2026

I accepted M1.6 after the Windows Server 2022 MSVC Release check joined Debian 12/13 and Ubuntu 24.04/26.04 with **five green GitHub Actions checks**. The PR was merged and the Ubuntu 26.04 GUI was manually verified. This confirms Windows core/CLI CI only, not Windows 10/11 desktop GUI qualification.

## M1.7 quality infrastructure — issue #9

I added first-party compiler warning policies, warnings-as-errors opt-in, Linux CLI-only Debug AddressSanitizer/UndefinedBehaviorSanitizer preset, clang-tidy 18 static analysis, workflow pin/permission checks and negative policy tests, and a weekly GitHub Actions Dependabot review queue. I retained the accepted OpenCV 5.1.0 pin, Windows dependency consumer check, all five OS workflows, and the historical C++ test suite.

**Local structural validation:** CMake presets and sanitizer rejection paths, workflow YAML, offline CI policy/negative tests, dependency pin integrity, patch replay, source ZIP equivalence, and unchanged historical JPEG bytes. These do **not** constitute a native ASan/UBSan test or hosted clang-tidy execution.

**Native acceptance pending:** I must run first-party warnings-as-errors Release and sanitizer Debug on Ubuntu, preserve the nine CTests, and receive a green Quality Actions job alongside five green distribution CI jobs. Document results before accepting issue #9.

## M1.7 acceptance and M1.8 provenance audit preparation (reported November 9, 2026)

I recorded 9/9 native Release CTests, 9/9 ASan/UBSan CTests, successful local clang-tidy and CI policy checks, and the six passing GitHub Actions checks reported before merging M1.7. M1.8 adds a source-level rights assessment, SHA-256-backed rights manifest, deterministic validation, and policy regression tests. These tests check *integrity and disclosure of unresolved rights*, not proof of copyright ownership. The archival photographs remain explicitly excluded from the MIT code license, and the release rights gate stays blocked pending verified permission or replacement. Per-artifact notices and SBOMs remain future release gates.

## M2.1 owned ImageFrame contract — implementation pending native acceptance

I added the owned frame value type, a deep-copy OpenCV adapter, an ImageFrame-aware Skittles entry point, and CLI/GUI integration. The original nine CTests are unchanged; two dedicated frame tests bring the suite to 11. The milestone is **pending native Ubuntu 26.04** Release, sanitizer, and GUI verification and the six hosted GitHub Actions checks. M1.8 audit passed with unresolved fixture release rights intentionally blocked; M2.1 does not change those images or their manifest.

## M2.1 acceptance / M2.2 implementation — November 10, 2026

I accepted M2.1 after **11/11 CTests** passed in native Release, CLI-only
Release and ASan/UBSan Debug configurations on Ubuntu 26.04. The original
Skittles counts remained 19 / 8 / 19 / 16 during GUI verification. My
`clang-tidy-18` run completed without blocking diagnostics, and all six
GitHub Actions checks passed before the M2.1 pull request was merged.

For M2.2, I added an OpenCV-independent generalized result contract,
legacy-result adapter, two dedicated CTests, and full historical sample
conversion assertions. My locally executed, dependency-free C++ contract test
passed **33 checks**, including an ASan/UBSan run under Clang. An independent
compatibility test using a minimal OpenCV declaration stub passed **18 checks**;
that stub is **only** a syntax/contract test and is not a native OpenCV build.
Existing fixture SHA-256 values remain unchanged. The expected native suite is
**13 CTests**. The actual OpenCV 5.1.0 compile, CTests and six hosted CI jobs
must pass before accepting issue #12.

The one-line `clang-tidy` messages such as "3 warnings generated" do not
identify the files or checks responsible. The M2.1 scanner used `--quiet`,
which can hide diagnostics in external headers. A passing analysis exit status
is not evidence that there are no suppressed or third-party warnings; I must
run it without `--quiet` and inspect diagnostic locations if I want to classify
them. I will not silence actionable first-party defects merely to remove the
counts. The historical-photo redistribution gate remains intentionally blocked.

## M2.2 acceptance and M2.3 processor registration — issue #13 (November 10, 2026)

I accepted M2.2 after native Ubuntu Release/CLI and sanitizer testing, manual
GUI review, and six successful GitHub Actions checks, followed by merging the PR.

For M2.3, I introduced the explicitly registered `IProcessor` interface,
validated numeric profile schemas, and an adapter that runs the unchanged
Skittles detector through the M2.1 owned-frame and M2.2 generalized-result
contracts. The CLI and GUI now route analysis through the registry and use a
strict legacy presentation adapter to preserve existing output formats. M2.3
adds **four CTests**, for **17 total**, including negative cases and the
four-image object-level comparison of old and registered processing.

Prepared-source checks are not a substitute for a real OpenCV build or Actions:

- [ ] Release GUI/CLI with warnings-as-errors: 17/17 CTests.
- [ ] CLI-only Release: 17/17 CTests.
- [ ] ASan/UBSan Debug: 17/17 CTests without violations.
- [ ] Static analysis includes new processor implementation and test units.
- [ ] CLI `--list-profiles`, `--profile skittles`, and invalid-profile rejection.
- [ ] GUI shows the registered Skittles profile and preserves accepted sample results.
- [ ] All six distribution/quality GitHub checks pass and issue #13 is merged.

I do not claim that a compiler's warning-count summary alone identifies an
actionable first-party `clang-tidy` issue. For diagnosis I capture a targeted,
non-quiet `clang-tidy-18` run with source locations and diagnostic names rather
than suppressing or changing warning policy without reviewing the details.

## M2.3 acceptance and M2.4 bounded asynchronous processing — issue #14 (November 10, 2026)

I accepted M2.3 after 17/17 native Release, CLI-only, and ASan/UBSan CTests
passed, the GUI retained its expected detections, and all six hosted Actions
checks passed before merging the pull request. I investigated the reported
`clang-tidy-18` warnings: all 19 first-party translation units finished with
zero exit failures; the warning summaries were suppressed non-user-header
diagnostics. An opt-in scan of GCC 15 system headers reported two
`bugprone-use-after-move` diagnostics in `bits/stl_vector.h` and `<format>`,
not in ChromascopeIP source. These toolchain-header diagnostics are recorded
rather than suppressed by weakening first-party checks.

For M2.4 I introduced a single-worker latest-wins queue, stop-token aware
processor execution, GUI result polling, explicit cancellation, and two new
CTest targets (19 total). The four historical image fixtures and their rights
policy remain unchanged. Native OpenCV 5.1.0 compilation, complete CTests,
ASan/UBSan, manual GUI tests, and all six Actions jobs remain **PENDING** at
patch preparation time. See `docs/ASYNC_PROCESSING.md`.


## M2.5 — Independent annotation layer and OpenCV renderer (issue #15)

I accepted M2.4 after 19/19 Release, CLI-only Release, and ASan/UBSan CTests,
manual GUI rapid-switch/cancel/re-run acceptance, and all six hosted GitHub
Actions checks (November 10, 2026). Its PR was merged.

For M2.5 I extracted presentation-only geometry, RGB colors, and owned labels
into an `AnnotationLayer` and added an explicit detection-to-annotation bridge.
I moved the OpenCV legacy renderer into a dedicated translation unit, keeping
its public API as a compatibility wrapper, and switched CLI/GUI drawing to the
new layer without changing the original Skittles detector or JSON schema.
The independent reference renderer in the new integration test compares all
pixels for both label modes across s1.jpg–s4.jpg.

Acceptance remains **pending** until I run 21/21 native CTests in Release,
CLI-only Release, and ASan/UBSan configurations, the static analysis gate, GUI
visual/export regression, and six hosted Actions checks. I will not regard a
stub-only or synthetic-only build as an OpenCV 5.1.0 qualification.

## M2.5 acceptance and M2.6 resource-budget preparation — issue #16 (November 10, 2026)

I accepted M2.5 after **21/21** native CTests in Release, CLI-only Release,
and ASan/UBSan configurations (the sanitizer suite passed twice); I also ran
the two annotation-focused tests, verified the GUI labels/export/rapid
switching/cancellation manually, and observed six passing GitHub Actions
checks before merging the PR. The supplied annotated image preserved the
expected historical Skittles detections.

For M2.6 I introduced bounded still-image reads and supported-format header
inspection before the OpenCV decoder, common decoded/owned-frame limits,
processing workspace and candidate-list guards, complete numeric CLI argument
validation, and four new CTests (**25 total**). The historical samples,
processing defaults and third-party version requirements are unchanged.

Prepared-source checks: independently compiled and executed the C++
resource/header test (**24 checks passed**) using GCC/C++20 with
`-Wall -Wextra -Wpedantic -Werror`; all four JPEG dimensions were inspected
without decoding; Python quality tests passed (**10/10**); CI policy checks
passed; CMake registered **25** CTests using a test-only OpenCV configuration
stub. None of these establish native OpenCV 5.1.0 build success.

**M2.6 acceptance pending:** 25/25 tests in Ubuntu Release, CLI-only Release
and ASan/UBSan; focused `-L budget`; static analysis; manual GUI inspection
and all six GitHub Actions checks. I will keep issue #16 In Progress until
these complete and the PR is merged.

## M2.6 acceptance and M2.7 test-coverage preparation — issue #17 (November 10, 2026)

I accepted M2.6 after correcting an oversized-BMP fixture's dimensions,
rerunning my local test and GUI checks, and observing six successful hosted
GitHub Actions checks before merging the pull request for issue #16.

For M2.7 I added five focused C++ test executables, for **30 CTests total**.
I did not change any production code, third-party dependency pins, sample
media, or CLI/GUI user-facing behavior. The new targets enforce concurrent
latest-ticket publication, pending/active image lifetime, stop/join behavior,
stored-image coordinate and ROI rules, and the strict Skittles legacy bridge.
The expected local acceptance matrix remains Release GUI + CLI, Release CLI
only, ASan/UBSan CLI, and first-party static analysis.

**Preparation evidence (not the native acceptance result):** I compiled and
executed the OpenCV-independent new tests with GCC 14.2.0 and C++20 in an
isolated environment using warnings-as-errors. I have not verified the two
new OpenCV-dependent tests, the complete 30/30 suite, or the six hosted CI
jobs as part of this M2.7 preparation; those gates remain **PENDING**.
I will record their actual outcomes before marking issue #17 done.

## M3.1 generalized still-image filters — implementation pending native verification

I have prepared issue #18 from my accepted M2.7 archive. The change adds
explicit grayscale, Gaussian blur, binary threshold and Canny edge profiles;
registered parameters, owned output rasters, shared GUI/CLI presentation,
and five headless CTests (expected suite size: **35**). The original Skittles
profile, default settings, JSON/export compatibility and all four fixture
photographs remain untouched. The acceptance matrix, CLI commands, and safety
limitations are documented in `IMAGE_FILTER_PROFILES.md`. I have **not yet
recorded** a successful native OpenCV 5.1.0 full build, GUI run, sanitizer
matrix, or hosted GitHub Actions for this prepared patch. I will enter those
results after execution before closing issue #18.

## M3.1 acceptance and M3.2 implementation preparation — November 10, 2026

I accepted M3.1 after confirming that all **35/35 CTests** passed in the
Ubuntu 26.04 GUI Release, CLI-only Release and ASan/UBSan test configurations.
The five `filters`-labeled tests passed separately, the GUI still rendered the
legacy Skittles objects, and I confirmed the new image-transform profiles
changed the preview correctly. All six hosted GitHub Actions checks passed
on the M3.1 PR and the PR was merged, as reported before issue #19.

I then prepared M3.2 from the accepted `Post_M3_1.zip` source baseline. This
adds two registered geometric profiles (HSV selection and Canny contours),
region detections, source/mask overlay selection, generic JSON geometry output,
raw mask export and seven new regression/CLI tests. I preserve the original
Skittles JSON schema, the M3.1 transform behavior and the historical samples.
**The prepared M3.2 CTest suite contains 42 tests.**

Source package validation and CMake test registration are not substitutes for
native OpenCV 5.1.0 builds. I will report actual Release, CLI-only, sanitizer,
GUI and hosted Actions results before closing issue #19.

## M3.5 — CLI profiles, JSON versioning, and output paths (pending acceptance)

GitHub Issue #22 introduces explicit schema v1, profile-first validation,
conflict rejection, and an opt-in export directory. Expected native test count:
**48** (46 existing plus two new headless tests). No new GUI controls or
image-processing algorithms are intended. The implementation and tests were
prepared from the supplied post-M3.4 archive; **native OpenCV 5.1.0 builds,
sanitizer tests, and hosted CI are not yet verified in this record**.

Local acceptance checklist:

```bash
cmake --preset linux-release -DCHROMASCOPE_WARNINGS_AS_ERRORS=ON
cmake --build --preset linux-release --parallel
ctest --preset linux-release --output-on-failure
ctest --test-dir build/presets/linux-release -R 'cli_m3_5|unit_cli_output_paths' --output-on-failure
cmake --preset linux-cli-release -DCHROMASCOPE_WARNINGS_AS_ERRORS=ON
cmake --build --preset linux-cli-release --parallel
ctest --preset linux-cli-release --output-on-failure
cmake --preset linux-cli-sanitize
cmake --build --preset linux-cli-sanitize --parallel
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
    ctest --preset linux-cli-sanitize --parallel 1 --output-on-failure
python3 scripts/check_ci_policy.py
python3 scripts/check_provenance.py
git diff --check
```

Manually check the output directory under `--output-dir`, inspect both Skittles
and Gaussian JSON, reject `--output` pointing to the source photograph, and
recheck the unchanged GUI's profile switching, overlay export, and zoom/pan.
After successful verification, confirm all six GitHub Actions checks before
accepting issue #22.


## M3.5 acceptance / M3.6 regression preparation — November 11, 2026

The user confirmed merging M3.5 (#22) after successful native Ubuntu 26.04
GUI Release, CLI-only Release and ASan/UBSan executions, each with **48/48
CTests passing**; both focused M3.5 checks passed, and manual CLI/GUI behavior
was verified. The six required hosted CI checks (Ubuntu 24.04, Ubuntu 26.04,
Debian 12/13, Windows MSVC core/CLI, and Ubuntu quality) passed before the
merge. Local clang-tidy produced summary warning counts but no reported
blocking failure; CI policy and local historical fixture provenance checks
reported PASS. These are user-supplied acceptance results for the prior issue.

M3.6 (#23) adds five headless checks for still-image formats, malformed or
unsupported inputs, source-image fixture invariants, CLI failure modes, and
manifest integrity under intentionally corrupted **copies**. The anticipated
CTests count is **53**. The header unit test has been compiled under the
working environment's C++20 compiler and passed 24 checks; the isolated
CMake manifest-corruption exercise passed. **Full OpenCV 5.1.0 builds, new
real-codec/CLI tests, sanitizers, GUI regression verification and hosted CI
are pending**, not inferred from those partial checks.


## M3.6 acceptance and M4.1 dependency preparation — November 11, 2026

The user reported passing **53/53 CTests** in native GUI Release, CLI-only
Release and ASan/UBSan builds on Ubuntu 26.04. The five `formats` tests also
passed separately. Local quality/provenance checks and ten Python policy tests
passed, and all six hosted GitHub Actions checks were green before the M3.6
merge. This is user-reported acceptance evidence for issue #23.

M4.1 (#24) changes isolated OpenCV 5.1.0 dependency builds and adds a
camera-free backend smoke test (expected **54 CTests**). On Linux, the new
FFmpeg-enabled installation must be installed to a fresh prefix, and the
selected prefix provided to **every** CMake preset. No native OpenCV 5.1.0
build or hosted M4.1 CI result has yet been supplied; all tests and dependency
probes remain final acceptance gates.


## M4.1 acceptance / M4.2 preparation — November 11, 2026

The user reported successful independent installed-package verification of
OpenCV 5.1.0 `videoio` with synthetic MJPEG/AVI round-trips on Ubuntu 26.04;
**54/54 CTests passed** in GUI Release, CLI-only Release, and ASan/UBSan.
The M4.1 `videoio` CTest passed separately. Quality/provenance and 10 Python
checks passed; six hosted Actions jobs passed before the M4.1 PR was merged.
Manual still-image GUI and CLI regression checks also passed. The `clang-tidy`
summary warning counts are not by themselves evidence of new actionable errors.

M4.2 (#25) adds the owned, indexed, timestamped recorded-file `VideoSource`
contract and two new headless CTests (expected **56**). Source-level checks
performed during patch preparation do not replace native OpenCV 5.1.0 builds.
M4.2 remains pending native build/test results, manual GUI checks, sanitizers,
static analysis and all six hosted CI checks.


## M4.2 acceptance / M4.3 preparation — November 11, 2026

The user reported successful native **56/56 CTests** for GUI Release, CLI-only
Release and ASan/UBSan using isolated OpenCV 5.1.0 videoio. Video-specific
checks and manual unchanged-GUI regressions passed. Static analysis, CI policy,
fixture provenance and ten Python tests completed; all six GitHub Actions
jobs passed before M4.2 (#25) merged.

M4.3 (#26) implements worker-thread decoding, seeking, generation-based
cancellation and bounded event/byte buffering. Two new headless CTests
increase the expected suite from 56 to **58**. Preliminary GCC unit and
ASan/UBSan checks using a synthetic VideoSource substitute passed, but
full native OpenCV 5.1.0 compilation and hosted CI remain pending.


## M4.4 — GUI recorded-video player (#27)

M4.3 native baseline: 58 CTests passed in GUI Release, CLI Release, and
ASan/UBSan; policy, provenance and Python quality gates passed. The user
reported that GitHub did **not** execute the usual six checks before the
M4.3 merge; cross-platform CI acceptance of M4.4 remains outstanding.

M4.4 adds two CTests (expected total **60**), headless transport tests
and interactive GUI recorded-video verification. The current handoff patch
is not yet accepted until native and hosted verification succeed.


## M4.4 acceptance / M4.5 CLI video preparation — November 11, 2026

The user supplied local **60/60 CTests passed** in Ubuntu GUI Release,
CLI-only Release, and ASan/UBSan builds; all seven video-labeled checks passed
separately, quality/provenance and ten Python policy tests completed, and
manual playback/still-image GUI checks were reported successful. The user also
supplied a screenshot of all six successful hosted GitHub Actions checks and
confirmed that M4.4 (#27) was merged. This establishes the accepted M4.4
baseline without representing the M4.5 implementation as already qualified.

M4.5 (#28) introduces two new headless CTests, expected total **62**, for
CLI video probing, strict numeric frame extraction, lossless PNG pixels, JSON
schema v1, and path/argument rejection. Local preliminary tests of strict CLI
numeric/extension validation are not a substitute for native OpenCV builds.
M4.5 acceptance remains pending GUI and CLI native Release testing, all 62
CTests, ASan/UBSan, clang-tidy and policy/provenance gates, manual unchanged-GUI
regressions, and six successful hosted GitHub Actions checks.

## M4.5 acceptance / M4.6 preparation — November 11, 2026

The user confirmed all **62 CTests** passed in Ubuntu GUI Release, CLI-only
Release and ASan/UBSan, plus the two focused M4.5 CLI-video cases, CI-policy,
fixture provenance and ten Python quality checks. They also confirmed unchanged
GUI/CLI behavior, six successful GitHub Actions checks, and the M4.5 merge.

M4.6 (#29) adds rotation and timestamp-source contracts, bounded VFR-aware
playback pacing, unknown-FPS fallback and explicit video-only audio handling.
The expected suite is **65**. Preliminary C++ policy and offline patch checks
must not be confused with native OpenCV integration or hosted CI acceptance.


## M4.6 Ubuntu 24.04 Quality CI portability correction — pending hosted sign-off

On the M4.6 pull request, `Quality / ubuntu-24.04 / First-party ASan UBSan clang-tidy`
failed during its **Release compilation**, before CTest, ASan/UBSan or clang-tidy could run.
The hosted GCC 13.3.0 compiler emitted `-Werror=maybe-uninitialized` while inlining
`video_presentation_delay()` from `VideoMediaPolicy.hpp` into `VideoPlayer::update()`.
The caller previously constructed optional presentation times using a nested
conditional aggregate initializer, which confused GCC's optimized data-flow
analysis. The correction value-initializes `VideoTimeSample` before assigning
available timestamp values and leaves the timing policy unchanged.

Added focused unit assertions for missing decoder-reported values and mixed
estimated/reported timing, including both absent-optional paths. Compiling
`VideoPlayer.cpp` at `-O3 -DNDEBUG -Wall -Wextra -Wpedantic -Wformat=2 -Werror`
provides an explicit regression check. The expected CTest count remains **65**.

The original diagnostic was reproduced independently with GCC 14.2.0 using
those flags, then resolved without disabling warnings. The M4.6 unit test
passes under GCC 14 Release and ASan/UBSan. **Hosted GCC 13.3.0 verification,**
all six GitHub Actions jobs and final merge acceptance remain pending.

## M4.6 CI correction accepted / M4.7 development — November 12, 2026

The M4.6 GCC 13 optimized compilation fix was verified by the user locally.
Their screenshot confirms all **six** GitHub Actions checks passed on the
corrective pull-request revision, and they confirmed the PR was merged.
The M4.6 suite remains at **65** registered CTests, all of which passed
in local GUI Release, CLI Release, and sanitizer configurations.

M4.7 (#30), "Create synthetic video-fixture generation and error-path tests",
adds three registered tests (expected **68 CTests**) using generated MJPEG
media and malformed samples under the CTest build tree. Initial headless
policy checks do not establish native OpenCV/CLI execution. Final acceptance
requires all 68 CTests in the usual local configurations, sanitizer and
static analysis, unchanged GUI/CLI operation, and all six hosted checks.

## M4.7 accepted / M5.1 (#31) research and license selection — November 12, 2026

The user confirmed that M4.7's corrected one-frame EOF regression passed,
**68/68 CTests** succeeded in GUI Release, CLI-only Release, and ASan/UBSan
configurations, and all six GitHub Actions checks passed before the merge.
M4.7 is accepted as the Milestone 5 baseline.

M5.1 selects **OpenCV Zoo NanoDet-Plus-M 1.5x FP32 ONNX** for future
multi-class inference, with explicit Apache-2.0 directory license evidence,
a published model SHA-256, source/attribution/redistribution notices and
out-of-source weight handling. See [`M5_1_MODEL_SELECTION.md`](milestones/M5_1_MODEL_SELECTION.md).
The research gate adds one offline manifest/notice CTest; the **expected
suite is 69 CTests**. No third-party model, training data, or OpenCV DNN
runtime changes are shipped at M5.1. The existing photo-redistribution and
binary packaging license reviews remain open.

**Preliminary verification is not final acceptance:** check the new manifest
CTest, Python manifest checker and the quality tests, then run native GUI,
CLI-only and ASan/UBSan builds and **69/69 CTests** in each configuration. The
six hosted Linux/Windows/Quality Actions checks must pass on the final PR
revision before merging. Actual inference and package redistribution are
future milestones and cannot be accepted under this research issue.

## M5.2 (#32) — CPU DNN adapter and dependency migration (November 12, 2026)

M5.1 NanoDet research/attribution checks were accepted with 69 CTests and six
hosted checks. The M5.2 implementation requires pinned OpenCV 5.1.0 DNN in
all local and CI builds and adds a synchronous CPU-only, owned float32 tensor
adapter. The new `chromascope_unit_cpu_dnn_contract` and
`chromascope_integration_cpu_dnn_adapter` tests bring the expected suite to
**71 CTests**. The latter generates a weight-free ONNX ReLU graph inside its
CTest build directory and checks numeric forwarding and output independence.
No selected NanoDet checkpoint is fetched, bundled, or executed by CI.

**Preliminary verification** is limited to OpenCV-independent C++ tensor
contract tests, source/patch checks, and CMake/CI policy verification.
**Pending**: native OpenCV 5.1.0 DNN-enabled builds, Windows MSVC static
DNN/Protobuf link acceptance, the actual ONNX integration test, all 71 CTests
in each supported configuration, clang-tidy, ASan/UBSan, manual GUI regression,
and all six hosted GitHub Actions checks. M5.2 does not yet implement
NanoDet-specific detection preprocessing/postprocessing or package approval.

## M5.3 (#33) — Deterministic preprocessing (November 12, 2026)

M5.2 was accepted after the corrected DNN input binding passed 71 CTests in
GUI Release, CLI Release and ASan/UBSan, plus six hosted GitHub Actions checks.
M5.3 adds explicit 416×416 NanoDet RGB/mean/std/zero-pad preprocessing,
a configurable stretch mode, owned NCHW tensors, deterministic integer
letterbox geometry and reversible source-space mapping. Two headless tests
bring the expected suite to **73**. No model weights or new external assets.

**Preliminary verification is not final acceptance.** Validate native OpenCV
5.1.0 GUI and CLI Release, 73 CTests in both plus ASan/UBSan, clang-tidy,
policy/provenance, manual still-image/video regression and six hosted Actions
jobs before merging.


## M5.3 accepted / M5.4 (#34) pending native acceptance — November 12, 2026

The user verified the M5.3 two-test preprocessing group, 73/73 CTests in GUI
Release, CLI-only Release, and ASan/UBSan, plus quality/provenance checks and
all six hosted GitHub Actions jobs before merging M5.3.

M5.4 introduces OpenCV-independent NanoDet contiguous COCO-80 class names,
inclusive confidence gating, bounded model-space candidate validation, exact
M5.3 inverse geometry mapping/clipping, deterministic class-aware greedy NMS,
and owned source-space `DetectionResult` output. No ONNX weights, model
loading or real detector decoding is introduced. Two CTests increase the
expected count to **75**. Preliminary local GCC/Clang/sanitizer checks are not
native OpenCV 5.1.0 qualification: all full Release/sanitizer/quality suites,
manual GUI/CLI regressions and hosted CI jobs must pass before accepting #34.

## M5.4 accepted / M5.5 (#35) GUI detector controls — November 12, 2026

User-reported M5.4 baseline: 75/75 CTests each in GUI Release, CLI-only Release,
and ASan/UBSan; clang-tidy and 16/16 Python quality tests completed; all six
GitHub Actions checks succeeded before the reported merge. M5.5 exposes a
NanoDet CPU object-detection profile, independently verified model status,
background model load and raw CPU inference diagnostic, as well as visible
confidence/NMS/max-detections settings. No raw model-output decoder, labeled
object detections, inference overlays or detector exports are claimed. The
new `DnnGuiSession` limits pending work and ignores stale/cancelled responses;
file hashing uses the M5.1 pinned ONNX SHA-256 before OpenCV parses model bytes.

Two new headless CTests raise the expected count to **77**. Local focused
hash/lifecycle tests and syntax checks are preliminary, not final native
qualification: accept only after real OpenCV 5.1.0 GUI/CLI Release builds,
77/77 CTests in each required local configuration, sanitizers, clang-tidy,
manual GUI/CLI regressions and all six hosted CI checks on the final revision.


## M5.5 accepted / M5.6 (#36) CLI general object detection — November 12, 2026

The user verified M5.5 with 77/77 CTests in GUI Release, CLI-only Release and
ASan/UBSan, clang-tidy and 16/16 Python quality tests; all six hosted GitHub
Actions checks passed before the merge. The GUI loaded the actual pinned ONNX
and displayed the expected six raw NanoDet output shapes. Warnings observed
while switching images required re-verifying/reloading the model as designed;
they are not evidence of a failed test. M5.5 is accepted.

M5.6 adds a real NanoDet box decoder, CPU model-backed CLI `--profile object`,
required SHA-256-verified `--model`, confidence/NMS/max detections controls,
source-space COCO-80 JSON schema v1 and optional annotated image export. The
existing GUI remains raw-inference-only. Two headless CTests raise the expected
suite to **79**. Preliminary standalone GCC and sanitizer verification of the
decoder and C++ syntax checks do **not** qualify native OpenCV 5.1.0 inference.
Acceptance requires full Release/sanitizer/quality suites, actual pinned-model
CLI JSON and annotation comparison, manual classic/video regressions, and all
six hosted CI jobs on the final PR revision.

## M5.6 model-policy correction — local ONNX vs bundled weights

The native M5.6 Release, CLI-only Release and ASan/UBSan runs each passed
78/79 tests; test #69 rejected the separately downloaded, Git-ignored pinned
ONNX checkpoint stored at the GUI's default model path. The standalone Python
model-policy quality test failed for the same reason. The M5.1 policy was
corrected to distinguish untracked, SHA-256-verified developer model files
from Git-tracked or source-archived weights. Model binaries are still excluded
from commits and release artifacts. The full 79-test suite and six hosted
GitHub Actions checks remain outstanding for the corrected revision.


### M5.6 — Native CLI output ordering and Debian Git ownership correction

The user reported all 79 CTests and 20 Python quality tests passing locally,
while the verified NanoDet CLI failed before export with
`Unexpected NanoDet score/distribution tensor shape`. The M5.5 GUI and actual
model showed that OpenCV 5.1.0 exposes three score tensors followed by three
distribution tensors; the original decoder wrongly expected alternating pairs.
The corrected decoder identifies heads by validated anchor and channel counts
and tests grouped and interleaved ordering, malformed or duplicated heads, and
stride-64 optional heads. Additionally, Debian 12/13 CI CTest #69 failed
with `fatal: detected dubious ownership`, because the model policy invoked Git
inside a checkout owned by a different UID. CMake and Python model-policy Git
queries now use command-scoped trust for the precise checkout path, retaining
strict weight tracking, ignore, and checksum checks.

Final verification remains pending: native actual-model CLI JSON/image exports,
79/79 tests in all local configurations, 21/21 Python quality tests, and all
six hosted CI checks on the final PR revision. No pretrained weights or
new dependencies are part of this correction.

## M5.7 (#37) — Model provenance and adversarial object fixtures (pending native acceptance)

The user confirmed M5.6 real-model JSON/image exports, **79/79 CTests** in
native configurations, all applicable Python quality and static checks, and
all **six** hosted Linux/Windows checks; the correction for NanoDet tensor
ordering and Debian Git trust was merged. M5.6 is the accepted M5.7 baseline.
The Skittles image's weak `kite` predictions are out-of-vocabulary model errors,
not proof that the software incorrectly decoded the selected checkpoint.

M5.7 adds an independently checked artifact provenance record; five original
SHA-256-pinned media fixtures with reproducible generator; adversarial image
and tensor rejection; a pre-forward layer-count cap; and offline policy tests.
No model binary, media rights change, GUI inference-control change, or new
third-party dependency is introduced. The acceptance target is **82 CTests**
(previously 79) and **25 Python quality tests** (previously 21).

**Preliminary non-native verification is not acceptance:** require native
OpenCV 5.1.0 Release GUI, CLI-only Release, ASan/UBSan, clang-tidy, policy,
fixture provenance, manual GUI/CLI regressions, and all six GitHub Actions
checks. Model accuracy, calibration, class-aware confidence policy, and
out-of-vocabulary abstention are deliberately deferred to M5.8 before M6.

## M5.7 accepted / M5.8 proposed — November 13, 2026

The user confirmed **82/82 CTests passed** in GUI Release, CLI-only Release,
and ASan/UBSan, with M5.7 model provenance/fixture checks, all applicable
static/Python checks, manual GUI/CLI regression, and all six hosted GitHub
Actions checks. PR #37 was merged. M5.7 is the accepted M5.8 baseline.

M5.8 adds a conservative default COCO confidence cutoff of 0.50, explicit
COCO-80 class enumeration, per-class acceptance thresholds, score-bearing
object annotations, and an abstention/uncertainty summary that never invents
an unknown object category. The synthetic policy regressions use the two
weak `kite` candidate scores observed in the user's Skittles photo without
requiring or committing the pretrained ONNX weights. Added `uncertainty` and
`class_thresholds` JSON fields preserve existing version-1 keys. Accuracy is
**not** calibrated and is not qualified by these tests.

Expected new suite: **84 CTests** (+2); the existing Python quality test
count remains **25**. Require native OpenCV 5.1.0 GUI and CLI Release,
ASan/UBSan, clang-tidy, policy/provenance, manual CLI/GUI regression,
real-model sample inspection, and all six hosted CI checks before acceptance.
M6 should reuse this confidence policy before frame-wise detection/tracking.

## M6.1 (#38) — Recorded-video frame object detection (pending native acceptance)

The M5.8 baseline was accepted by the user: 84/84 GUI Release CTests, 84/84
CLI Release CTests, 84/84 sanitizer CTests, repository quality checks, manual
GUI/CLI regressions and all six GitHub Actions checks passed before merging.

M6.1 introduces `RecordedVideoObjectDetector`, a common still/video frame
postprocessing API, and `--detect-video-frame` to run the same verified NanoDet
backend on a selected zero-based video frame. Three headless tests increase
the expected CTest suite from **84 to 87**, without model weights. Independent
media timestamp availability and provenance are preserved. A pipeline failure
never masquerades as a successful empty detection result. No video tracking,
continuous inference or GUI playback integration is claimed.

**Outstanding acceptance gates:** native OpenCV 5.1.0 builds, 87/87 CTests
under GUI Release, CLI-only Release and ASan/UBSan, clang-tidy, repository
policy/provenance checks, manual real-ONNX video frame JSON/PNG export and
existing GUI/CLI regression, and all six hosted GitHub Actions checks.

## M6.1 CLI video probe compatibility correction — pending native acceptance

The first native M6.1 run compiled successfully and passed all three new
M6.1 CTests, but the existing M4.5 `chromascope_cli_video_probe_extract`
regression failed in GUI Release, CLI-only Release and ASan/UBSan. The test
correctly expected the pre-existing `cannot use still-image` diagnostic for
`--video-probe --profile skittles`, whereas M6.1 had inadvertently replaced
it with the narrower `cannot use object-profile options` message.

Restored an accurate combined diagnostic covering both still-image and
object-profile option misuse, without loosening rejection behavior. Extended
the existing M4.5 test to cover the still-image profile on extraction and the
M6.1 object profile on video probe. No CTest registrations or detection
algorithms changed; the expected suite remains **87 CTests**.

**Acceptance remains pending:** focused CTest #62, full 87 CTests in all
three configurations, quality checks, real-model manual video-frame export,
and six hosted GitHub Actions checks on the final PR revision.

## M6.1 accepted / M6.2 (#39) pending — November 13, 2026

The user reported **87/87 CTests passed** in GUI Release, CLI Release and
ASan/UBSan after the M6.1 video-probe diagnostic correction. Manual GUI/CLI
regression and recorded-frame NanoDet JSON/PNG exports passed. All six hosted
GitHub Actions checks were green before merging PR #38. No sample-video or
ONNX weight binary is added to source control.

M6.2 introduces independent off-thread full-recording inference, bounded
progress/cancellation, a 256-result cache, and original-coordinate, exact-frame
playback overlays. Two headless tests increase the expected suite to **89**;
25 Python quality tests remain. Preliminary completion of synthetic tests is
not native signoff. Require native OpenCV 5.1.0 builds, all 89 CTests in the
three configurations, static analysis/policy/provenance, manual GUI playback
and cancellation with a real local model, regression of legacy processing,
and all six GitHub Actions checks before closing #39.

## M6.2 accepted / M6.3 (#40) pending — November 13, 2026

The user confirmed **89/89 CTests** in GUI Release, CLI-only Release and
ASan/UBSan, 25 Python quality tests, repository clang-tidy/policy/provenance,
responsive independent playback/inference, correct matched-frame overlays,
zoom/seek/cancellation, and no cross-recording artifacts. All six hosted CI
checks passed, and PR #39 was merged. Two sample videos were included only in
the local archive; no recording binaries were committed.

M6.3 introduces forward-only whole-recording CLI analysis with streaming JSONL
start/frame/end records, optional frame-step sampling and a strict decoded-frame
limit. The single existing pinned NanoDet model instance is reused, and the
full M5.8 confidence policy, original frame identity/timing and output safety
rules are preserved. Two offline CTests raise the expected suite to **91**.
Incomplete limit hits are explicitly marked and exit nonzero; a failed stream
never emits a success marker. No ONNX weights, third-party movies, or GUI
behavior changes are included in this milestone.

**M6.3 acceptance pending:** native OpenCV 5.1.0 GUI and CLI Release builds,
all 91 CTests in Release/CLI-only/ASan-UBSan, static analysis, 25 Python quality
tests, policy/provenance, real-model stdout/file JSONL verification, existing
GUI/video/Skittles regressions, and all six hosted Linux/Windows CI checks.

## M6.3 accepted / M6.4 (#41) pending — November 13, 2026

M6.3 was accepted after **91/91 CTests** passed in GUI Release, CLI-only
Release, and ASan/UBSan, 25 Python quality tests passed, and all six GitHub
Actions jobs succeeded. The user verified full 270- and 330-frame recordings
and JSONL frame-step outputs (including expected exit code 2 on hard limits).
M6.3 was merged before starting M6.4.

M6.4 introduces explicit MJPEG/AVI-only annotated exports and required
source-audio-drop acknowledgment. One frame is decoded, detected, annotated,
and encoded at a time; CFR output cannot preserve original VFR timing. An
atomic no-overwrite publish occurs only after confirmed EOF and writer closure.
A GUI jthread provides progress and cancellation, but OpenCV `forward()`
remains uninterruptible until return. New synthetic and CLI-negative CTests
bring the **expected test total to 93**; Python quality remains 25. No model
weights or user-supplied video files are committed in this milestone.

**M6.4 is pending native acceptance.** Run OpenCV 5.1.0 GUI Release,
CLI-only Release, ASan/UBSan (93/93), clang-tidy, provenance/CI policy,
25 Python quality checks, real-model silent AVI creation and replay, GUI
cancellation/output cleanup, and all six hosted CI jobs before merging #41.

## M6.4 accepted / M6.5 (#42) pending — November 13, 2026

M6.4 was accepted after **93/93 CTests** passed in GUI Release, CLI-only
Release and ASan/UBSan, all **25 Python quality tests** passed, and six hosted
Debian/Ubuntu/Windows/quality checks succeeded. The user manually verified
M6.4 GUI/CLI behavior, exported the FrenchHorn sample, and merged PR #41.
An independently inspected submitted `annotated.avi` was MJPEG/AVI, 1920×1080,
25 FPS, 270 video frames, and no audio stream. Neither the source sample movie
nor the output AVI is committed as a test fixture.

M6.5 adds three headless cross-layer regression CTests for recorded-frame
postprocessing after seeking, stale overlay generation isolation, streamed
frame-step ordering/EOF/error handling, and annotated-video encoded pixels,
FPS override, no-overwrite, and canceled/failed staging cleanup. The expected
suite is **96 CTests**; Python quality remains at 25. These tests synthesize
MJPEG files under the build tree, inject deterministic model outputs, and do
not require a local ONNX checkpoint or external video footage.

**M6.5 is pending native acceptance.** Run the three new CTests first, then all
96 in GUI Release, CLI-only Release and ASan/UBSan, clang-tidy, CI/provenance
policy and Python tests, and manual recorded-video/AVI/JSONL regressions. All
six hosted checks must succeed before merging #42.

## M6.5 accepted / M6.6 (#43) pending — November 13, 2026

M6.5 was accepted after the user confirmed **96/96 CTests** in GUI Release,
CLI-only Release, and ASan/UBSan, 25 Python quality checks, manual GUI/CLI
regressions, and all six hosted Debian/Ubuntu/Windows/quality checks. The PR
for issue #42 was merged before M6.6 started.

M6.6 adds independent CPU steady-clock stage timing: decode and inference
in streaming recorded-video JSONL and GUI asynchronous inference; overlay
construction/drawing and encoding in MJPEG/AVI export. The GUI reports
per-repaint CPU overlay submission separately from exporter rasterization.
One bounded fixed-size accumulator per operation and additive timing output
preserve the existing media, frame identity, codec/audio, detection/JSONL
completion, cancel and transactional export policies. Explicit sample counts
prevent unknown stages from being mislabeled 0 ms. Model loading, GPU work,
file publication and end-to-end process runtime remain unmeasured. Two
synthetic, model-free CTests raise expected count **96 → 98**.

**M6.6 pending native acceptance:** build with the pinned OpenCV 5.1.0
DNN/videoio configuration, run 98/98 Release, CLI Release and ASan/UBSan
CTests, clang-tidy, 25 Python quality tests and policy/provenance checks;
manually verify JSONL timing, GUI timing display, and a complete silent AVI
export; require all six hosted GitHub Actions checks before merging #43.

## M6.6 accepted / M6.7 untracked confidence-parity improvement — November 13, 2026

The user confirmed **98/98 CTests** in GUI Release, CLI-only Release and
ASan/UBSan, 25 Python quality checks, manually verified the GUI, JSONL and
silent MJPEG/AVI output, and observed all six Debian/Ubuntu/Windows/quality
GitHub Actions checks passing. M6.6 was merged before this M6.7 work.

A source audit found that M5.8's conservative 0.50 default, COCO-80 labels,
per-class overrides, and weak-candidate filtering were already used by
recorded-video backend/CLI. M6.7 adds no model heuristic: it supplies missing
interactive GUI score captions, in-workspace supported-class listing, editable
weak diagnostic floor, frame-matched status/weak-candidate presentation, and
bounded whole-recording diagnostic counts; encoded AVI exports report the same
weak summaries. Confidence is not calibrated probability. Weak candidates are
not classified unknown objects. The expected suite becomes **100 CTests** with
two offline coverage additions; Python quality remains 25.

**M6.7 native acceptance pending:** pin OpenCV 5.1.0 with DNN/videoio; run 100
CTests in GUI Release, CLI-only Release and ASan/UBSan, clang-tidy, provenance
and CI policy, and 25 Python quality tests. Manually confirm preview/AVI
confidence captions, per-class override effects, uncertain-only versus no-
evidence frames, cancellation/reset, and existing GUI/CLI regressions. Require
all six hosted checks before merge. No official GitHub issue number is assigned
for this supplemental milestone. See `docs/history/milestones/M6_7_VIDEO_CONFIDENCE.md`.

## M7.1 (#44) — Person model evaluation and license, pending native acceptance

**Prior accepted baseline:** User verified M6.7 with **100/100 CTests** in GUI
Release, CLI Release, and ASan/UBSan; all six hosted Debian/Ubuntu/quality/
Windows checks passed and M6.7 was merged. Existing model, audio, video,
confidence policies and sample rights are unchanged by this research milestone.

M7.1 records upstream OpenCV Zoo person class `0`, reported COCO 2017 val
person AP50 `0.675` and AP50:95 `0.418` **as third-party benchmarks only**,
and Apache-2.0 terms; no measured ChromascopeIP person precision/recall is
claimed. The stdlib-only tool `scripts/evaluate_person_detections.py` supports
future, locally authorized, independently labeled person data. It refuses
truncated JSONL, incomplete/misaligned frame labels, mismatched model/media
hashes, invalid rectangles and unreviewed data. These are engineering policy
and unit tests, not runtime accuracy measurements or legal release clearance.

**Expected after M7.1: 102 CTests; 34 Python quality tests.** Run both focused
`-L person` tests and all three full native CTest configurations, the regular
clang-tidy and CI/provenance scripts, original GUI/CLI regression checks, and
six hosted CI workflows. No model weights or video data in Git/patch. Actual
model inference against independently labeled representative media is a
separate future evaluation gate; no pass/fail accuracy targets have been
established in this M7.1 research-only milestone.


## M7.1 accepted / M7.2 (#45) pending native acceptance

The user verified **102/102 CTests** in GUI Release, CLI Release and
ASan/UBSan and **34/34 Python quality tests**. Six hosted Debian/Ubuntu/
quality/Windows checks passed before the M7.1 merge.

M7.2 adds the `person` detection profile and its independent display cutoff
(default 0.50) to the existing verified NanoDet COCO-80 backend. The shared
postprocessor suppresses non-person boxes/weak evidence before recording
results, but continues validating malformed non-person candidates. It changes
no object-profile thresholds, codec, model, frame lifecycle or media rights.
Recorded-video GUI chooses person-only or general detection and cancels stale
overlays when profile/cutoff changes. CLI supports still images, indexed video
frames, JSONL and AVI exports in person mode. See `docs/history/milestones/M7_2_PERSON_PROFILE.md`.

**Expected suite after M7.2: 105 CTests and 36 Python quality tests.**
Native OpenCV 5.1.0 Release/CLI/sanitizer tests, clang-tidy, provenance,
manual GUI/CLI/video/AVI regressions, and all six hosted checks are required
before accepting M7.2. The synthetic test fixture is not an accuracy
benchmark; person precision and recall still require independent ground truth.

## M7.3 (#49) — Person boxes in still-image GUI (pending native acceptance)

M7.2 baseline accepted with **105/105** native GUI/CLI/sanitizer CTests,
**36/36** Python quality tests, and six hosted jobs according to the user's
report and screenshot. M7.3 closes the GUI gap without changing the pinned
model, shared class-0 postprocessor, CLI contracts, video/AVI pipeline, or
historical-media rights.

New CTests: `chromascope_integration_person_still_boxes` and
`chromascope_integration_person_still_gui_session` (expected total **107**).
Before merging: all three Linux configurations must report 107/107,
quality scripts and all six GitHub checks must pass. Manual GUI testing must
verify load/verification, person-only box labels and source-pixel alignment,
confidence/display thresholds, stale-result clearing on setting/image/model
changes and cancellation, zero-person result, PNG export and classical/video
regression. No claim of measured recognition accuracy is made. See
`docs/history/milestones/M7_3_PERSON_BOXES.md`.

## M7.4 (#50) — Scenario regression acceptance (pending native verification)

M7.3 was accepted after **107/107 CTests** in GUI Release, CLI Release and
ASan/UBSan, plus the six hosted CI jobs and manual still/video UI checks.
M7.4 adds one headless generated-MJPEG regression and four stdlib-only Python
tests: expected **108/108 CTests** per native configuration and **40/40
Python quality tests**. Also require `git diff --check`, pinned model/fixture
provenance and CI-policy scripts, clang-tidy, and all six GitHub Actions jobs.

M7.4 verifies post-forward contracts and evaluator error accounting for crowded,
small/large, partially occluded, cropped and empty scenes. This is NOT a
measured model recall/precision result: no real-world NanoDet evaluation or
trained-weight changes are introduced. The hand-authored synthetic data are
safe to version; external people videos remain untracked and must have their
rights reviewed separately. See `docs/history/milestones/M7_4_PERSON_SCENARIOS.md`.

### M7.5 (#51) preparation — person-only entry points

The previous 108/108 CTests and 40 Python quality tests passed on M7.4 and
all six hosted checks were reported green; the PR was merged. M7.5 adds
GUI toolbar shortcuts for still/video person-only mode and a CLI `--person-only`
alias with strict argument conflict guards. Expected suite **109 CTests**.
Final native Release, CLI-only Release, sanitizer, static analysis, manual
GUI/CLI, and six hosted checks remain pending until user verification. See
`docs/history/milestones/M7_5_PERSON_WORKFLOW.md`.

### M7.5 accepted / M7.6 (#52) privacy controls pending user verification

The user reported all **109/109 CTests** passing in GUI Release, CLI-only
Release and ASan/UBSan, plus static analysis and **40/40 Python quality
tests**. Screenshot confirms all six hosted CI checks green; user confirmed
M7.5 merged. M7.6 adds no person identification or new inference logic.

M7.6 introduces an explicit GUI session reset, disables ImGui automatic
layout/log file persistence, adds no-input CLI `--privacy-info`, and records
the actual runtime, disk-export, dependency, media-rights, memory-cancellation
and OS/third-party privacy boundaries. One CTest and three Python tests raise
the expected counts to **110** and **43**, respectively. All three native
configurations, six hosted checks, manual GUI reset/privacy validation,
clang-tidy, and provenance remain **pending final user acceptance**.

The documentation/contract tests do **not** establish comprehensive absence
of all third-party or OS networking, forensic erasure, or approval to
redistribute third-party people footage. See `docs/history/milestones/M7_6_LOCAL_PRIVACY.md`.

### M7.6 accepted / M8.1 (#53) pending local and hosted verification

User reported GUI Release 110/110, CLI Release 110/110, ASan/UBSan 110/110,
43/43 Python quality checks and successful first-party policies/static analysis,
manual GUI/CLI parity, and six successful hosted CI jobs. User confirmed M7.6
was merged after the GitHub screenshot. M8.1 adds explicit V4L2/MSMF backend
selection, opt-in Windows DirectShow fallback, a move-only camera core adapter,
BGR8 frame ownership and capture-clock semantics, and an offline CLI backend
registry report. Expected **113 CTests** and **45 Python quality tests**.
Native build, real-device testing and hosted CI for M8.1 **not yet verified**.
This milestone does not claim GUI webcam support or universal camera hardware
compatibility. See `docs/history/milestones/M8_1_CAMERA_BACKENDS.md`.

### M8.1 accepted / M8.2 (#54) pending verification

The user reports **113/113 CTests** on GUI Release, CLI Release and ASan/UBSan,
**45/45 Python quality tests**, successful clang-tidy and provenance checks,
and all six GitHub Actions jobs green after M8.1. User confirms M8.1 merged.
M8.2 introduces passive bounded discovery, strict requested camera format
negotiation, categorized failures, three offline CTests and two Python guards.
Expected: **116 CTests / 47 Python tests**. Native/hosted/manual M8.2
acceptance is pending user verification. See `docs/history/milestones/M8_2_CAMERA_DISCOVERY.md`.


### M8.3 (#55) qualification

Run the GUI Release, CLI Release and CLI ASan/UBSan presets, and `ctest`
with `-L camera`; expect 118 native CTests, including both new async camera
checks. Run Python quality suite (49), clang-tidy and provenance/CI policy
checks. No automated test opens real camera hardware.

### M8.5 (#57) CLI opt-in camera capture acceptance

Run all CTests in GUI Release, CLI Release, and CLI ASan/UBSan; run camera
label CTests, Python quality, clang-tidy and provenance. Expect 122 native
CTests and 53 Python tests when tests are enabled. Then manually verify an
authorized real camera with `--camera 0 --camera-max-frames 10
--camera-max-seconds 5`, optional create-only PNG directory, and invalid
indices/permission/error behavior. Verify all six hosted CI jobs. The CI
contract never opens hardware and driver calls are not guaranteed to return
by the application polling deadline. See `docs/history/milestones/M8_5_CAMERA_CLI.md`.

## M8.6 (#58) mock camera failure-injection preparation

Created a reusable, test-only `CameraFrameReader` mock and two new native
CTest targets for exact frame/timestamp generation, injected open/read faults,
invalid frame packets, worker thread ownership, stop/restart and queue bounds.
Expected totals are **124 native CTests** and **55 Python quality tests**.
Mock tests are hardware-independent and do not prove real driver behavior;
full native/OpenCV and hosted CI acceptance must be recorded after running
on supported systems. See `docs/history/milestones/M8_6_CAMERA_MOCK.md`.

### M8.7 (#59) documented Linux webcam hardware qualification (pending)

M8.6 baseline: GUI Release, CLI Release and ASan/UBSan **124/124**, camera
**14/14**, Python quality **55/55**, static analysis/provenance checks and six
hosted Actions passed, per local log and user confirmation of M8.6 merge.
M8.7 adds an opt-in Linux V4L2 hardware smoke runner, four hardware-free
Python quality regressions (expected **59**), and an operator checklist.
Run passive mode separately, then explicit `--run-hardware` to observe two
actual bounded captures; optionally persist PNGs and sanitized JSON via
create-only paths. A report alone cannot certify device release or GUI LIVE
status. Real webcam evidence and manual GUI/error scenarios are required for
M8.7 acceptance; **do not record hardware PASS without that evidence**.
See `docs/history/milestones/M8_7_LINUX_CAMERA_SMOKE.md`.

### M9.1 (#60) — live camera inference bridge (acceptance pending)

Accepted M8.7 baseline (per local operator log): 124/124 CTests in GUI
Release, CLI Release and CLI ASan/UBSan; 14/14 camera tests; 59/59 Python
quality tests; clang-tidy and policy/provenance checks passed. Explicit Linux
V4L2 repeated native capture and create-only PNG smoke validation passed;
manual GUI/CLI regressions and six CI jobs were confirmed successful.

M9.1 adds explicit live model inference to the GUI via a separately authorized
worker with one pending input and one immutable exact-frame result. It shares
the pinned NanoDet object/person processing path and has no tracker/identity
or new recording/export path. Pending final local OpenCV 5.1.0/ImGui builds,
126 CTests, 61 Python quality tests, manual hardware/model verification and
six hosted Actions checks. See docs/history/milestones/M9_1_LIVE_CAMERA_INFERENCE.md.

### M9.2 (#61) live inference non-blocking scheduling — acceptance pending

M9.1 baseline: 126/126 CTests in GUI Release, CLI Release, and CLI sanitizer;
16/16 camera CTests, 61/61 Python quality tests, clang-tidy, provenance and
all six Actions green; manual GUI/CLI inference behavior confirmed by the
operator. M9.2 adds an explicitly configurable one-pending-frame drop policy,
capture-timestamp pacing, per-session diagnostics, two native tests and two
Python quality checks. **Expected: 128 native / 18 camera / 63 Python quality.**
Actual OpenCV GUI builds, CPU/ASan tests, webcam and ONNX behavior, manual
regressions and hosted CI must be reverified before acceptance. Synthetic
queue tests do not establish device-side frame drops or real-time inference
performance. See `docs/history/milestones/M9_2_LIVE_INFERENCE_SCHEDULING.md`.

### M9.3 (#62) synchronized live detection overlay — acceptance pending

M9.2 was accepted after local sanitizer 128/128 and 50 consecutive focused
runs per test, full GUI/CLI Release 128/128, Python quality 63/63, manual
functional regressions and six hosted CI checks. M9.3 adds testable exact
frame-to-overlay identity, original-space clipping, canvas zoom/pan projection,
label placement and independent presentation toggles. Expected acceptance:
130 GUI/CLI/sanitizer native tests, 20 camera CTests, 65 Python quality tests,
full static analysis and provenance, manual webcam NanoDet boxes/labels,
existing GUI/CLI regressions and six GitHub Actions checks. Do not record
hardware PASS from synthetic tests. Details: docs/history/milestones/M9_3_LIVE_OVERLAY.md.

### M9.4 (#63) — Temporary tracking acceptance (pending)

M9.3 baseline: local GUI Release, CLI Release and CLI sanitizer suites passed
130/130; camera suite passed 20/20, Python quality 65/65; the operator reports
manual GUI/CLI regression success and six hosted CI checks passed before merge.

M9.4 adds a bounded, opt-in session-local IoU tracker and two native tests plus
two Python quality tests (expected 132/132 and 67/67). Track IDs must be gated
by exact M9.3 source-frame matching. No camera/model access, persistent state,
identity recognition or recorded-video behavior changes are permitted.

Final sign-off requires complete local builds, ASan/UBSan, static analysis,
provenance checks, webcam tracking and lifecycle manual acceptance, and six
GitHub Actions successes on the M9.4 commit. Until verified: NOT ACCEPTED.
See docs/history/milestones/M9_4_TEMPORARY_TRACKING.md.

### M9.5 (#64) acceptance — pending local verification

M9.4 baseline accepted: 132 native CTests, 22 camera CTests and 67 quality
checks; user confirmed manual GUI and six hosted Actions passing. M9.5 adds
2 native CTests and 2 Python quality tests: expected 134 / 24 / 69.
Headless tests cannot certify physical camera, GUI controls, model latency or
actual FPS. Full native Release/sanitizer, local hardware, privacy and hosted
CI acceptance remain required; see docs/history/milestones/M9_5_LIVE_GUI_CONTROLS.md.

### M9.6 (#65) — pending real camera and cross-platform qualification

M9.5 baseline accepted following user-confirmed 134 native CTests, 24 camera
CTests, 69 quality tests, manual GUI/CLI checks and six green Actions jobs.
M9.6 adds two native unit/integration CTests, two negative CLI CTests and two
Python quality tests. Expected: 138 native, 28 camera, 71 quality. Verify
Ctrl-C response, JSONL start/frame/end completeness, limits, model integrity,
privacy, stdout and create-only destinations on real webcam hardware. Local
Release and ASan/UBSan, static analysis and six Actions jobs must pass before
acceptance. See docs/history/milestones/M9_6_CLI_LIVE_JSONL.md.

### M9.7 (#66) — real-device performance/recovery/tracking acceptance (PENDING)

M9.6 baseline accepted with 138 native CTests, 28 camera CTests, 71 quality
tests, real Linux CLI JSONL and graceful SIGINT, plus operator GUI checks and
six green hosted workflows. M9.7 adds a passive JSONL verifier, explicitly
opt-in Linux hardware supervisor, and 15 Python quality regressions; expected
138 / 28 / 87. Headless verification does **not** certify device disconnect,
permission handling, real tracking IDs, GUI performance or Windows hardware.
Record manual PASS/FAIL/NOT_TESTED per platform as specified in
`docs/history/milestones/M9_7_LIVE_DEVICE_QUALIFICATION.md`. Until operator sign-off: **NOT ACCEPTED**.

### M10.1 (#67) — responsive GUI usability (PENDING local acceptance)

M9.7 baseline was operator-accepted after 138 native CTests, 28 camera CTests,
87 Python checks, Linux V4L2 hardware qualification, manual GUI/CLI work and
six hosted green CI checks. M10.1 adds two headless native presentation-policy
CTests and two Python quality checks; expected 140/28/89. GUI sizing, style
scaling, browser interactions, shortcuts and contextual help require manual
DPI/monitor/OS verification; CI alone cannot certify their actual appearance.
No production inference, video, camera, tracking or CLI behavior is changed.
See `docs/history/milestones/M10_1_GUI_EXPERIENCE.md`. Acceptance pending local and hosted checks.

### M10.2 (#68) — acceptance pending

M10.1 accepted baseline: user reported 140 native CTests across GUI Release,
CLI Release and CLI ASan/UBSan, 89 Python quality tests, manual GUI regressions,
and six hosted GitHub Actions checks. M10.2 adds two native tests and two Python
quality tests (expected 142 / 28 camera / 91 quality). Real Linux and Windows
GUI preferences roundtrip, corruption/permission tests, privacy boundaries,
full build suites and hosted CI remain final acceptance requirements.
See `docs/history/milestones/M10_2_VERSIONED_PREFERENCES.md`.

### M10.4 (#70) — performance measurement baselines (PENDING)

M10.3 baseline operator-accepted after 144/144 CTests in GUI Release, CLI
Release and ASan/UBSan, 93/93 Python quality checks, documented JSONL export
and GUI/CLI regression checks, and six green GitHub Actions jobs. M10.4 adds a
passive offline performance report and opt-in bounded native CLI profiling of
wall-clock time, process CPU, peak RAM and optional device-wide GPU telemetry.
No production C++ or native CTests are changed: expected **144/28/107**.
Manual reproducibility, full source gates, GUI performance, physical camera
qualification and six hosted CI checks remain required; no speedup is claimed.
See `docs/history/milestones/M10_4_PERFORMANCE_BASELINES.md`.

### M10.5 (#71) — filesystem, media, model, and camera security review (PENDING)

M10.4 operator acceptance and all six CI jobs were reported before this audit.
M10.5 adds a structured threat model and eight read-only Python quality guards;
no native tests or production paths change (expected **144 native CTests,
28 camera-labeled, 118 Python quality tests**). Sign-off on this **research
artifact** requires traceable evidence, prioritized R-01–R-08 mitigations, and
explicit follow-up ownership. Do not claim a general security certification or
that the absence of a reproduced critical bug proves memory safety. Full native,
Python, static-analysis, manual privacy and six hosted CI gates remain required.
See `docs/history/milestones/M10_5_THREAT_BOUNDARY_AUDIT.md`.

## M10.6 (#72) acceptance supplement — malformed media and budgets

M10.5 baseline from user acceptance: **144 native CTests**, **115 Python
quality tests**, six successful hosted checks and manual GUI/CLI verification.
M10.6 adds three native tests and eight Python quality tests (expected
**147 native CTests** and **123 Python tests**). Required verification:

- Run each new CTest in GUI Release, CLI Release and CLI ASan/UBSan.
- Run the full 147-test native suites and 123-test Python quality suite.
- Confirm the video seed regression uses only bounded, incomplete files in
  build-tree test-artifacts, not real media or cameras.
- Confirm corpus validation and create-only binary materialization without
  modifying `samples/`, pinned models, or tracked test fixtures.
- Re-run CI policy, provenance, object provenance, model-selection and clang-tidy.
- Manually re-check still-image/video playback, CLI/video, camera opt-in and
  image/person results; all six hosted GitHub checks must pass before merge.

This is regression coverage of known first-party boundaries, **not** a claim
of comprehensive third-party decoder fuzzing or an exploit-free build. The
M10.5 threat register remains open for isolation, file-identity and resource
mitigations requiring separate engineering review.

## M10.7 (#73) — Extended validation preparation (pending operator sign-off)

Added 17 no-hardware Python supervisor regressions and a bounded, opt-in
synthetic/recorded-video/V4L2 live soak runner. The accepted M10.6 baseline
is **147 native CTests**, **28 camera CTests**, and **123 Python quality
tests**; M10.7 expects **147 / 28 / 140**. Production C++ is unchanged.

Acceptance is NOT implied by an offline PASS: rerun all 147 GUI/CLI Release
and CLI ASan/UBSan CTests, clang-tidy, 140 Python tests, provenance/policy,
repeated synthetic soaks, extended recorded-video and explicitly authorized
real-camera soak where available. Record native Windows 10/11 manual checks
separately from Windows Server CI. Hosted six-check CI, operator GUI/device
observations and real-hardware/resource measurements remain pending until
tested against the exact M10.7 commit. See
[M10_7_SANITIZER_STATIC_SOAK.md](milestones/M10_7_SANITIZER_STATIC_SOAK.md).

## M10.8 (#74) — Current GUI/CLI, privacy, troubleshooting and architecture documentation

M10.8 adds the [documentation index](../DOCUMENTATION_INDEX.md),
[current GUI](../USER_GUIDE.md), [CLI reference](../CLI_REFERENCE.md),
[privacy guide](../PRIVACY_GUIDE.md), [troubleshooting](../TROUBLESHOOTING.md) and
[current architecture](../CURRENT_ARCHITECTURE.md). They describe the
**accepted M10.7 baseline**, while earlier M0–M10.7 pages remain historical.
`tests/quality/test_documentation_m108.py` adds **13 hardware-free checks** for
links, CLI flags, safe examples, source boundary terms, privacy permissions,
architecture layout and documentation discoverability. No production code,
CTest registry, camera access or ONNX model loads are changed.

Expected local test baseline after M10.8: **147 native CTests, 28 camera-labeled,
153 Python quality tests** (140 + 13). Use the full Python suite, native GUI
Release, CLI Release and ASan/UBSan, clang-tidy, provenance/CI policy, manual
GUI/CLI acceptance and six hosted CI checks. The documentation tests validate
consistency with selected source contracts; **they are not** a substitute for
manual camera/platform verification or a comprehensive documentation accuracy
proof. See [M10.8 guide index](../DOCUMENTATION_INDEX.md).

## M11.1 (#75) — relocatable install and staging (PENDING)

The accepted M10.8 baseline was 147 native (28 camera-labeled) and 153
Python tests with six green hosted checks. M11.1 introduces two native CTests
(resource lookup and install/relocate staging), five Python source-policy tests
and installation rules for both frontends, documentation and model metadata.
Expected: **149 native CTests**, **28 camera-labeled**, **158 Python quality
tests**. Verify stage relocation and absence of unapproved photos/weights,
manual GUI sample-button availability in a checkout versus absence in a stage,
custom prefixes and `DESTDIR` on Linux; run full sanitizer/static-analysis,
model/provenance gates and all six existing CI jobs. M11.1 deliberately does
**not** bundle OpenCV, codecs or DLLs. Only M11.2 onward can qualify clean
installed execution. See [M11.1 staging guide](../M11_1_INSTALL_STAGING.md).


## M11.2 (#76) — Debian 12 AMD64 package acceptance (PENDING)

Previous M11.1 accepted baseline: 149/149 native CTests in each of three modes,
28/28 camera tests, 158/158 Python quality tests and six green GitHub Actions
checks, followed by merge confirmation. New M11.2 expected baseline: **149
native**, **28 camera** and **179 Python quality** tests.

The M11.2 CI packaging correction closes the private OpenCV library graph
recursively from the five requested modules, including DNN -> FLANN where
required by ELF metadata. Five additional quality regressions guard the
closure and preserve failure on missing, incompatible or out-of-prefix modules.

Acceptance requires native Debian 12 AMD64 `.deb` construction from the pinned
OpenCV 5.1.0 source revision, valid dpkg metadata, isolated OpenCV SONAME closure,
Debian system dependencies derived by `dpkg-shlibdeps`, no media/model bundles,
and successful clean Debian 12 minbase apt-install + CLI processing smoke **without
a development OpenCV prefix**. This source contribution does not assert that
its Debian 12 package or six new CI results have passed yet. See
[M11.2 Debian 12 packaging](../M11_2_DEBIAN12_PACKAGE.md). GUI desktop, physical
cameras, release dependency notices, SBOM and final binary qualification remain
future M11.8/M11.9/M12 gates.

### M11.2 follow-up: installed Bookworm ELF loader resolution (PENDING)

The Debian 12 package now builds and installs in a fresh Bookworm chroot,
but `chromascope-cli` previously failed to find `libopencv_videoio.so.501`.
The corrected package uses private `$ORIGIN`-relative `DT_RPATH` for transitive
OpenCV resolution, inspects the installed tree and re-extracted package ELF
tags and SONAME links, and prints bounded dynamic-loader diagnostics upon
clean-install failure. This is a narrowly scoped Debian 12 package exception,
not a global runtime-loader configuration change. Re-run native Debian 12
packaging and full clean-install CLI smoke before accepting #76.

Expected M11.2 follow-up: **149 native / 28 camera / 179 Python** tests.
Manual GUI/video/camera qualification and licensing sign-off remain pending.

### M11.2 unchanged loader failure — evidence required to unblock

November 17: clean Bookworm APT installation succeeded but CLI startup still
failed loading `libopencv_videoio.so.501`; source-presence, SONAME links, and
ELF DT_RPATH inspection alone were insufficient. Next CI run must show the
actual executable interpreter `--list` resolution and, on startup failure,
`LD_DEBUG=libs` search paths. The optional failed package artifact is named
**UNQUALIFIED** and is not a release candidate. Do not close #76 until native
clean-install execution, synthetic processing, and all six checks pass.
Expected: 24 focused Debian Python tests, 182 total Python tests, 149 CTests.


### M11.2 — verified proc-less chroot cause and two-sided smoke (PENDING)

The Debian 12 test chroot lacks `/proc/self/exe`. Real ELF inspection and a
controlled minimal-chroot reproduction confirmed `$ORIGIN` cannot be resolved
on a direct kernel exec there; the same binary works when given to its ELF
interpreter, or with executable location visible through procfs. See
Debian bug #787227. No Debian packaging payload or RPATH change is needed.

Acceptance now requires **ordinary native CLI startup** from the extracted
`.deb` on Debian 12 with `/proc/self/exe` available, with the private OpenCV
videoio path verified, PLUS full fresh-Bookworm APT installation and
interpreter-driven CLI help, profile, synthetic BMP processing. The latter is
not ordinary kernel exec inside the proc-less chroot. Do not waive any
pre-existing gates. Expected: 27 focused / 185 Python, 149 native, 28 camera,
and all six GitHub checks. M11.2 is blocked pending green CI.

## M11.3 (#77) — Debian 13 AMD64 candidate (accepted)

Native Debian 13 package creation and inspection, procfs-enabled native CLI
startup, and independent Trixie debootstrap APT/interpreter-driven help,
profiles and generated BMP smoke are mandatory. Preserve M11.2 Debian 12
qualification unchanged; all six hosted checks, the native 149 CTests
(including 28 camera), Python quality suite and manual GUI/CLI review are
required. The chroot lacks /proc/self/exe, so interpreter invocation is not
ordinary kernel-exec verification. No final v1.0 release or distribution
licensing sign-off is implied. See [M11.3 guide](../M11_3_DEBIAN13_PACKAGE.md).


### M11.3 acceptance recorded — November 17, 2026

The M11.3 pull request #77 received six successful GitHub Actions checks,
including the Debian 12 and Debian 13 packaging/clean-install jobs, and was
merged, as confirmed by the maintainer. Local verification recorded 11/11
focused packaging quality tests, 196/196 complete Python quality tests,
149/149 native Release, CLI-only and sanitizer CTests, and 28/28 camera-labeled
regressions. Manual GUI and CLI behavior was reported unchanged. Acceptance
establishes **Debian 13** package qualification at the development-candidate
level; it does not certify a signed v1.0.0 public release, standalone desktop
GUI install or camera hardware across all target systems.

## M11.4 (#78) — Ubuntu 24.04 AMD64 package (pending acceptance)

The native Noble package must pass source-pinned OpenCV provenance, recursive
private SONAME dependency closure, re-extracted `.deb` ELF inspection,
Ubuntu-generated `dpkg-shlibdeps` external Depends, ordinary native CLI startup
on a procfs-enabled host, and fresh Noble APT installation with interpreter-
driven CLI help/profiles/synthetic BMP processing. Keep Debian 12/13 packaging,
Ubuntu 26.04 builds, Windows, sanitizer and quality CI green. This is a
pre-release `0.1.3` candidate, not final distribution license or 1.0.0 approval.
Run the focused M11.4 Python policy tests and full suite; the 149 native CTests
and 28 camera-labeled regressions remain required, alongside manual GUI/CLI
checks and all six GitHub Actions checks. See [M11.4 guide](../M11_4_UBUNTU24_PACKAGE.md).

## M11.4 (#78) acceptance recorded — November 17, 2026

The maintainer reported 13/13 focused Ubuntu 24.04 package policy tests, 209/209
Python quality tests, 149/149 GUI Release, CLI-only Release and sanitized CTests,
28/28 camera CTests, preserved manual GUI/CLI behavior and six green hosted
GitHub Actions checks including the Noble clean-install package gate. PR #78
was subsequently merged. These establish qualified *development-candidate*
Ubuntu 24.04 packaging, not public release sign-off.

## M11.5 (#79) — Ubuntu 26.04 AMD64 package (pending native acceptance)

The separate Resolute package must pass source-verified OpenCV 5.1.0 provenance,
recursive private ELF/SONAME dependency closure, Ubuntu 26.04 dpkg-shlibdeps
metadata, post-extraction package inspection, ordinary native CLI launch with
procfs, fresh Resolute APT installation and interpreter-driven CLI help, profile
discovery and synthetic BMP processing. Preserve qualified Noble and Debian 12/13
packages, Windows and quality CI; all six hosted checks and local manual GUI/CLI
review remain necessary. Expect 149 native CTests, 28 camera CTests and 222
Python quality tests (13 new M11.5 tests). No model or historical media is
redistributed. This is a 0.1.3 candidate, not an approved v1.0.0 release.
See [M11.5 guide](../M11_5_UBUNTU26_PACKAGE.md).


## M11.5 (#79) acceptance recorded — November 17, 2026

Maintainer-confirmed 13/13 new Ubuntu 26.04 package quality tests,
222/222 complete Python tests, 149/149 Release GUI/CLI/sanitizer CTests,
28/28 camera CTests and intact manual GUI/CLI behavior. All six hosted
GitHub Actions checks passed, including native Resolute package and smoke,
then PR #79 was merged. The four Linux development distributions are
qualified at their respective CI gates; this is not v1.0.0 public sign-off.

## M11.6 (#80) — portable Windows x64 ZIP (pending hosted acceptance)

The new Windows Server 2022 / MSVC2022 x64 GUI-enabled configuration must
build CLI and GUI against static OpenCV 5.1.0, static GLFW 3.4 and pinned
Dear ImGui 1.93.0 and pass all registered CTests. The portable ZIP must be
reproducibly staged, inspect both executables' and bundled CRT DLLs' PE32+
imports, reject unknown imports/missing CRT and unapproved media/model assets,
record a SHA-256 manifest and explicit runtime/third-party notice inventory.
Only approved Microsoft x64 VC143 runtime files from the installed VS2022
redistribution folder may be staged app-local. Hosted CI must extract/relocate
and successfully launch CLI help, version, profile listing and processing
of a generated synthetic BMP under a PATH
without development OpenCV or VS directories. Interactive GUI, real Windows
10/11 and camera qualification, redist licensing sign-off and SBOM remain
M11.8/M11.9/M12. Existing Debian 12/13, Ubuntu 24.04/26.04 and six required
GitHub checks must stay green. Native Linux baseline: 149 CTests / 28 camera;
Python quality suite increases from 222 by the M11.6 additions. See
[M11.6 Windows ZIP](../M11_6_WINDOWS_PORTABLE_ZIP.md).


## M11.6 (#80) — Windows GUI MSVC first-build correction (pending CI)

The first M11.6 Windows Server 2022 GUI-enabled CMake build failed compiling
`src/gui/main.cpp`, before package generation. A `small` local in the texture
upload path conflicts with Windows RPC's `small` macro (`char`); the Windows
SDK's legacy OpenGL headers do not declare `GL_CLAMP_TO_EDGE`. I renamed the
local to `resized_bgr` and used a local `GLint` constant with OpenGL value
`0x812F` while preserving the requested 3.3 context and texture behavior.
The focused M11.6 policy suite adds three checks (16 total, including an
actual syntax-only C++ macro/legacy-GL compile), raising the expected Python
quality suite to 238. The native baseline remains 149 CTests and 28 camera
regressions. The actual Windows GUI-enabled build, portable ZIP qualification
and all six hosted CI checks must still pass before issue #80 can be merged.


## M11.6 (#80) — VC143 runtime-directory false rejection (pending CI)

The second Windows hosted run successfully compiled and tested the GUI and
CLI, but the portable ZIP packager rejected `vccorlib140.dll` found in the
verified VS2022 `Microsoft.VC143.CRT` directory. The directory includes a
Microsoft managed-code runtime that ChromascopeIP does not require. Fixed
only the packager's source-directory enumeration to ignore this exact known
unused runtime: the PE-import and ZIP allowlists still reject it and all
other unreviewed DLLs. CI continues to authenticate every Microsoft
redistributable before packaging. Three new tests raise focused Windows
policy coverage to 19 and total Python quality coverage to 241; native tests
remain 149 (28 camera-specific). M11.6 stays BLOCKED until the Windows ZIP
build, dependency audit, relocated CLI smoke and six hosted checks pass.


## M11.6 (#80) — VC143 source-inventory / PE-import boundary (pending CI)

The next hosted Windows Server 2022 job again completed both frontends' MSVC
Release builds and CTests and signed Microsoft VC143 source validation, but
failed on `vcruntime140_threads.dll` in the same folder that previously
contained the unrelated `vccorlib140.dll`. These repeated false rejections
stemmed from treating every Microsoft redistributable source DLL as a mandatory
member of ChromascopeIP's narrow native runtime policy. **The source directory
is not the package dependency manifest.**

The correction inventories reviewed native CRT source files without rejecting
other installed DLL names. The actual application and transitive CRT PE import
tables, not the directory listing, determine which reviewed runtimes are
copied. `vcruntime140_threads.dll` is allowed for genuine C11 threads imports
but is otherwise excluded; managed `vccorlib140.dll`, debug CRT and unreviewed
imports remain prohibited. CI continues validating every Microsoft source DLL
signature and package inspection revalidates the exact PE dependency inventory
and recomputes the necessary runtime closure to reject unneeded bundled DLLs.
Five new tests cover arbitrary unused source DLL names, true thread-satellite
imports, duplicate/symlink rejection, a complete synthetic recursive
build/ZIP/inspect cycle, and refusal to build for an unreviewed PE import.
**Expected: 24 Windows-specific / 246 total Python tests, 149 native CTests,
28 camera tests.** The real hosted Windows ZIP and relocated CLI smoke are
still mandatory; M11.6 remains BLOCKED until all six checks pass.


## M11.7 — complete matrix qualification (#81; implementation awaiting CI)

The maintainer accepted M11.6 after 24/24 focused Windows ZIP quality tests,
246/246 full Python quality tests, 149/149 native CTests per established
configuration, manual GUI/CLI verification and six green GitHub Actions
checks; PR #80 was merged. This is the accepted starting baseline.

M11.7 introduces a *separate* `Package Matrix CI` workflow with three
same-commit reusable native workflows and a final job that independently
validates all five exact, smoke-qualified package artifacts. It refuses missing,
extra, stale/misnamed, unsafe, version-mismatched or structurally invalid
inputs. The artifact report records run ID, source commit, bytes and SHA-256.

**Acceptance still pending:** 262 Python quality tests (246 + 16 matrix
regressions), unchanged 149 native CTests/28 camera CTests, all original six
CI checks, plus all five native package smokes and the new final whole-matrix
artifact check. This is not public release approval, Windows 10/11 client GUI
qualification, camera device qualification, signing, rights/SBOM approval or
v1.0.0 version freeze. See [M11.7](../M11_7_PACKAGE_MATRIX.md).

### M11.7 artifact transfer CI correction (2026-11-17)

The first M11.7 Package Matrix CI run successfully built and smoke-tested
all five native packages, but validation stopped at the first download:
`Artifact not found for name: ChromascopeIP-0.1.3-Debian12-amd64`.
The source log actually recorded artifact
`ChromascopeIP-0.1.3-Debian12-amd64.deb`. `upload-artifact@v7`
`archive: false` ignores its explicit `name:` and names the artifact after
the file. All five downloader names have been aligned with their actual
`.deb`/`.zip` artifact names. Additional regression tests verify all five
producer-consumer contracts, exact download layout, digest enforcement and
distinct names for UNQUALIFIED archives and the matrix report. This does not
claim that the corrected workflow has passed; native hosted acceptance is
still required.

**Correction regression baseline:** 22 M11.7-focused tests and 268 total
Python quality tests (262 + six). Existing native CTests remain 149, including
28 camera-labeled tests. Full hosted matrix acceptance is pending.


## M11.8 (#82) — real desktop GUI and live-device qualification

M11.7 was accepted after 268 Python quality tests, the unchanged 149 native
CTests/28 camera-specific tests, 12 successful GitHub Actions checks including
all five same-run packages, and maintainer-confirmed merge. M11.8 adds a
**passive**, offline evidence tool and **23** Python regressions for the manual
Windows 10/11, Debian 12/13 and Ubuntu 24.04/26.04 desktop matrix. The expected
Python quality baseline is **291**; native CTests remain **149** (28 camera).

Run `python3 scripts/qualify_desktop_m118.py --help` and follow
[the M11.8 guide](../M11_8_DESKTOP_DEVICE_QUALIFICATION.md). Initial evidence
files are deliberately NOT_TESTED; physical GUI/camera observations are only
recorded after explicit operator work and local review. No hardware runs in
quality CI. A GitHub Actions PASS alone is not Windows 10/11 or live-device
certification. All six records must refer to the same source commit and
qualified package digests before a manual-evidence report can be generated.


## M11.9 (#83) — Binary dependency and notice inventory

The maintainer reports M11.8 local GUI/CLI success, successful smoke-testing
of native packages in fresh OS VMs, twelve green hosted checks and merge.
These observations do not constitute independent per-device attestation or
redistribution-rights approval. M11.9 introduces *artifact-derived* offline
CycloneDX 1.6 draft inventories and explicit human review gates without
changing the production application or qualified package builders.

**Pending:** generate SBOM evidence from actual five same-run CI artifacts;
verify pinned source/third-party notices, Linux distro FFmpeg and codec builds,
Windows static components and VC143 licensing, and resolve any missing notices
or legal requirements. `REVIEW_REQUIRED` is not a release PASS. M12 signing,
version promotion and release remain blocked until applicable clearances.


## M12.1 (#84) — v1.0.0 release-candidate identity and scope freeze

CMake declares `project(ChromascopeIP VERSION 1.0.0 LANGUAGES CXX)` as the
authoritative application version. Both frontends consume a generated header;
Windows packaging, matrix verification and M11.8 QA read the same declaration.
The five package workflows, raw artifact names, matrix download destinations,
and M11.9 review artifacts use the `1.0.0` candidate identifier. Historical
M11 findings above retain their original `0.1.3` context and are not modified.

**Release status: BLOCKED / UNPUBLISHED.** The green M11.9 CI run validates
SBOM draft generation, not human redistribution clearance. M11.9 license/NOTICE
decisions, any incomplete M11.8 human device records, provenance release-gate
restrictions, signing and release artifacts must be resolved separately.
No tag, public GitHub release or automatic version promotion occurs here.

Required M12.1 gates: new offline version/scope contract tests; complete Python
quality suite; native Release/CLI-only/sanitizer CTests; CI action-policy checks;
all twelve hosted native/matrix checks; visual GUI/CLI version verification;
exact `1.0.0` package metadata and Windows ZIP inspection.


## M12.2 (#85) — final whole-release-candidate automated verification

The maintainer confirms acceptance and merge of M12.1 after local 326/326
Python quality tests, 150/150 native CTests, manual GUI/CLI verification and
12 successful GitHub checks. M12.2 adds a same-run top-level `Release
Candidate CI` workflow that requires the existing native five-package matrix
and complete Quality workflow to succeed together. The final gated job checks
frozen version identity, exact checked-out SHA, matrix report, all five actual
artifact-derived CycloneDX drafts and 29 pending rights-review topics.

**Baseline:** new 17 Python quality tests (343 total expected), 150 native
CTests (28 camera-labeled) unchanged. The real hosted final-candidate workflow
and workstation native verification are **PENDING** until executed on the M12.2
commit. No public release is created. The M11.9 third-party license and NOTICE
review, any incomplete M11.8 desktop/device evidence, and subsequent signing,
tagging and publication requirements stay **BLOCKED/PENDING** as appropriate.
See [M12.2 qualification guide](../M12_2_FINAL_RC_MATRIX.md).


## M12.3 (#86) — Linux clean-install engineering acceptance (fast-track)

The maintainer reports running the release-candidate packages on fresh Debian
12/13 and Ubuntu 24.04/26.04 VMs successfully with working installed GUI/CLI.
Four distribution-specific CI APT/chroot/CLI clean-install smokes and all 20
M12.2 release-candidate checks passed. The reported VM tests supplement, but
do not replace, the automated checks; they do **not** establish the exact
commit/package hash of each historical manual download or unreported steps
such as package removal/reinstallation.

M12.3 documents the existing evidence and offers the optional, private,
strict `scripts/qualify_linux_install_m123.py` record workflow. Its four
per-VM JSON files are **not required for Issue #86 engineering acceptance**.
If used, the tool correctly leaves unobserved cases `NOT_TESTED`, requires
same-run package digests, and cannot be treated as independent certification.
It should not delay release staging or force repeating already performed VM
install/GUI checks. M12.3 sign-off requires the reported four-VM behavior,
established native smokes and **green checks on the M12.3 PR**.

M11.9 redistribution/license approval, outstanding device-specific evidence,
release signing and publication remain **separate unresolved gates**; no
acceptance of #86 implies release authorization. The M12.2 Python baseline was
**343** tests and native CTest baseline **150** (28 camera-labeled); M12.3 adds
15 Python regressions and changes no native production or packaging code.


## M12.4 (#87) — Windows 10/11 portable ZIP engineering sign-off

The maintainer reports successful download/extraction and GUI/CLI use of the
portable Windows x64 1.0.0 candidate on Windows 10 and Windows 11. Existing
Windows Server 2022 MSVC CI, 150 native CTests, PE/VC143/ZIP inspections,
restricted-PATH relocated CLI smoke, five-platform artifact matrix and
full Release Candidate CI remain required and complementary evidence.

The [M12.4 Windows ZIP acceptance guide](../M12_4_WINDOWS_ZIP_ACCEPTANCE.md)
records this operator-reported success without inventing historical exact
ZIP hashes, commits, machine/driver details or unperformed camera tests.
No additional Windows JSON evidence records or retesting are required for
Issue #87 engineering acceptance when the existing 20 CI checks remain green.
M11.8 physical-device cases and M11.9 human license/NOTICE/codec and
Microsoft redistribution decisions remain separate. Neither signing nor
public v1.0.0 release is authorized by this issue.

## M12.5 (#88) — release dependency, license, vulnerability, privacy review

The maintainer confirms M12.4 was merged after **20 green GitHub Actions
checks**, manual GUI/CLI regression verification, and local **365/365 Python
quality tests**. Existing native Release, CLI-only, sanitizer and 150 CTest
baseline (28 camera-labeled) remains unchanged by M12.5, which adds only
review documentation and focused documentation/source-policy regressions.

**Current security and redistribution decision: BLOCKED for public release.**
The dated primary-source vulnerability review identified
**CVE-2026-8461** in distro-provided FFmpeg, with Debian 12 and Ubuntu
24.04/26.04 listed vulnerable on 2026-11-17; Debian 13 is listed fixed.
Actual OS runtime versions and decoder reachability remain unverified. The
29 outstanding M11.9 human review topics and known OpenCV notice
completeness question remain unresolved. The public-repository historical
photograph rights are separately unresolved. M10.8 first-party privacy
controls remain documented, but are not independent system-wide privacy
certification. See [the evidence and disposition guide](../M12_5_RELEASE_SECURITY_SIGNOFF.md).

M12.5 documentation engineering acceptance requires its new tests, complete
Python suite, release identity/provenance/policy checks, and unchanged 20
hosted checks. Its documentation can be merged independently of **public
redistribution authorization**, which requires separate substantiated
vulnerability and rights dispositions. No manual re-running of previously
successful Windows/Linux VM tests or historical commit reconstruction is
required solely by this documentation milestone.

## M12.6 — staged release checksums, CycloneDX and signed attestation readiness (Issue #89)

The maintainer accepted and merged M12.5 after 20 successful CI checks and
375 successful Python quality tests, with GUI/CLI behavior unchanged. The
**M12.5 security and legal release sign-off itself remains BLOCKED**; a green
CI check was only engineering acceptance of the documented review.

M12.6 adds a *manually triggered main-branch* release staging workflow that
reuses same-run native/quality/RC gates, revalidates package and five CycloneDX
SBOM identities and hashes, and prepares SHA256SUMS and a tag proposal.
The dedicated attestation job uses OIDC/Sigstore to create real signed
provenance and five SBOM attestations with narrowly scoped token permissions.
No tag, GitHub Release, or public binary publication is automatic. The local
annotated-tag automation requires previously completed M11.9/M12.5 reviews.
The new offline test suite checks the staging logic but does not issue actual
GitHub signatures. Host-side release staging/signature verification must pass
before M12.6 engineering acceptance. Public release authorization remains
blocked pending actual redistribution/security disposition.

See [M12.6 staging guide](../M12_6_RELEASE_STAGING.md).


### M12.6 hosted SBOM signature failure — corrective note

The first main-branch Release Staging CI run successfully completed full RC
qualification, downloaded five package artifacts and M11.9 inventories, verified
all 15 staged SHA256SUMS entries, and issued the five-subject provenance
attestation. The Debian 12 SBOM signing action then failed with
`Unsupported SBOM format. Must be valid SPDX or CycloneDX JSON.` Investigation
identified a missing top-level CycloneDX `serialNumber`. The generator now emits
deterministic UUIDv5 serial numbers for all five packages, and both RC and
staging validators reject missing/drifted SBOM identities before signing.
Hosted requalification is still required; no public release is authorized.


## M12.6 signed staging accepted / M12.7 final release documentation — November 17, 2026

Maintainer screenshots report success of the second complete Release Staging
CI run, including all native/quality prerequisites, final five-package staging
and six signed-attestation steps. A separately uploaded M12.6 staged bundle
contains five packages, five CycloneDX draft inventories, checksum manifest
and six Sigstore evidence JSON files. Local Python quality tests: 398 passed
(including release-stage, SBOM and RC validation). These observations do not
assert independent signature verification, real physical-device certification
or redistribution approval.

M12.7 adds release notes, changelog, installation instructions, synthetic
reproducible examples, an authentic screenshot-capture guide, and practical
release-rights/security disposition steps. No historical rights-unverified
Skittles photos or media are made distributable. M11.9's 29 review topics and
M12.5's FFmpeg/license findings remain BLOCKED until supported resolution. The
version is still 1.0.0; no Git tag or public GitHub Release is created.
