# Historical Skittles regression fixtures

I preserve the four original full-resolution JPEGs under `samples/skittles/`, rather than storing a second copy inside the test tree. The tests refer to these files using the absolute source-root path provided by CMake, so they work from any out-of-source build directory on Linux or Windows.

| Fixture | Resolution | Purpose |
| --- | --- | --- |
| `s1.jpg` | 4032 × 3024 | Wooden background; two orange and three red, including M0.1/M0.3 location regressions |
| `s2.jpg` | 4032 × 3024 | Wooden background; previously missed dark red |
| `s3.jpg` | 4032 × 3024 | Lined paper; orange/red classification boundary |
| `s4.jpg` | 4032 × 3024 | Lined paper; general baseline regression |

I record the byte-for-byte SHA-256 of each photograph in [`skittles.sha256`](skittles.sha256). The `chromascope_fixture_integrity` CTest verifies all four checksums before I treat the original-image regression evidence as valid. The C++ regression test separately checks decode dimensions, conservative object-count bands, per-color counts, and the known red/orange coordinates from M0.1/M0.3. It does not enforce identical timings or perfectly identical Hough coordinates across CPU architectures.

The synthetic test creates its own in-memory image deterministically. The CLI export test writes temporary artifacts inside the active build directory, never into `samples/` or the source checkout.

I don't assume that these photographs are covered by the source-code MIT license; their ownership and redistribution status are documented in [`docs/ORIGINS.md`](../../docs/ORIGINS.md).

## M3.6 still-image error and integrity regressions

The new `chromascope_regression_still_image_fixtures` CTest independently
checks encoded JPEG headers, BGR8 decoding, owned-frame dimensions, and
grayscale conversion for **all four original images**. The existing Skittles
regression retains its more specific object/category/coordinate assertions.

`chromascope_fixture_tamper_regression` makes **temporary copies under the
active build directory** and proves that the existing SHA-256 manifest gate
rejects altered bytes, missing fixtures, duplicate entries and invalid hashes.
It never edits the original photographs or changes their hashes.

Synthetic codec and malformed-input regressions likewise run only against
newly generated media under `build/`. None of these tests establishes
redistribution permission; the original release-blocking provenance policy
remains unchanged.

## Authorship evidence — 2026-11-18

The maintainer confirmed taking all four photographs with their own camera.
The original hashes, image bytes and all photographic regressions are unchanged.
The former permission hold is superseded by this owner statement; see
[media rights](../../docs/MEDIA_RIGHTS.md). The source-code MIT grant does not
automatically grant unrestricted reuse of these separately owned photographs.

The `magicyuv.avi.hex` and `cfhd.avi.hex` fixtures are original constant blue
frames encoded locally using FFmpeg's ordinary encoders, without exploit data.
The Linux decoder-policy probe materializes them in its test working directory,
uses a misleading `.mp4` suffix, and tests both ordinary and hostile codec
options. They are test inputs only and are never installed. Reproduction:

```bash
ffmpeg -f lavfi -i color=c=blue:s=32x32:r=1 -frames:v 1 -c:v magicyuv -pix_fmt gbrp -threads 1 NEW.avi
ffmpeg -f lavfi -i color=c=blue:s=64x64:r=1 -frames:v 1 -c:v cfhd -pix_fmt yuv422p10le -threads 1 NEW.avi
```

Container metadata can differ across FFmpeg versions; the committed hex bytes
are the test identity. These fixtures demonstrate enforceable rejection of valid
encoded input, not exploit reproduction or complete codec memory safety.
